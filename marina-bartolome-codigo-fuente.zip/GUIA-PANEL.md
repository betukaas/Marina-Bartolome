# Panel privado de Marina Bartolomé

Desde **tusitio.com/admin** cambias la carta, los precios, las fotos, el horario, las reseñas y
los textos principales sin tocar código. Guardas, y en 1 o 2 minutos la página se actualiza sola.

## Cómo funciona

```
Tú editas en /admin  →  se guarda en GitHub  →  Netlify reconstruye la página  →  sitio actualizado
```

- **GitHub** guarda el código y cada cambio (con historial: si algo sale mal, se regresa a la versión anterior).
- **Netlify** publica la página gratis y la vuelve a armar cada vez que guardas.
- El panel es privado: solo entra quien tenga acceso al repositorio de GitHub.

## Instalación (una sola vez, ~20 minutos)

1. **Crea una cuenta en GitHub** (gratis): https://github.com/signup
2. **Crea un repositorio** llamado `marina-bartolome` (privado) y sube ahí el código fuente
   (el contenido de `marina-bartolome-codigo-fuente.zip`).
   La forma más fácil: GitHub Desktop (https://desktop.github.com) → *Add existing repository* → *Publish*.
3. En `scripts/make-admin-config.py` cambia `TU-USUARIO-DE-GITHUB` por tu usuario y corre
   `python3 scripts/make-admin-config.py` (o edita directo la línea `repo:` de `public/admin/config.yml`).
4. **Conecta Netlify**: https://app.netlify.com → *Add new site* → *Import an existing project* →
   GitHub → elige `marina-bartolome`. Netlify lee `netlify.toml` solo; dale *Deploy*.
5. **Crea tu llave de acceso al panel**: en GitHub → *Settings* → *Developer settings* →
   *Personal access tokens* → *Fine-grained tokens* → *Generate new token*:
   - Repository access: *Only select repositories* → `marina-bartolome`
   - Permissions → Repository → **Contents: Read and write**
   - Copia el token y guárdalo en un lugar seguro (es como una contraseña).
6. Entra a **tusitio.com/admin** → *Iniciar sesión con un token de acceso* → pega el token.

## Qué se puede editar

| Sección del panel | Qué cambia |
| --- | --- |
| **Carta y precios** | Secciones, platillos, descripciones, precios, ★ estrella y 🌴 cocina local |
| **Favoritos de la casa** | Las tarjetas grandes con foto del inicio (orden, precio, foto) |
| **Fotos del sitio** | Portada, fachada, atardecer y fotos de platillos |
| **Contacto, horario y redes** | Teléfono, WhatsApp de reservas, dirección, horario, pagos, descuento isleños, redes |
| **Reseñas** | Reseñas destacadas (solo reales, copiadas de Google) |
| **Textos principales** | Títulos y frases de portada, cocina, historia, eventos y visítanos |

Todos los textos tienen **Español** e **Inglés**. Si dejas el inglés vacío, se usa el español.

## Consejos

- **Fotos:** súbelas en buena calidad. El sitio las recorta y optimiza solo al formato de cada lugar,
  así que el diseño no se mueve. Pon en «Qué se ve en la foto» una descripción corta.
- **Precios:** escríbelos como en la carta: `$565`, `$2.70 / g`, `$60 – $130`.
- **WhatsApp:** es el número al que llegan todas las reservas y eventos. Revísalo dos veces.
- Cada guardado queda en el historial de GitHub. Para deshacer un cambio: GitHub → *Commits* → *Revert*.

## Para cambios de diseño

El panel cubre el contenido. Si el dueño pide cambiar el diseño, agregar secciones o funciones nuevas,
eso se hace en el código (`src/`) y se sube a GitHub igual: Netlify publica solo.
