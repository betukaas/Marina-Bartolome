import { createContext, useContext, useState, type ReactNode } from 'react'

/** Datos con los que se puede abrir el panel de reserva ya prellenado */
export type BookingPrefill = { guests?: string; date?: string; time?: string; notes?: string }
type Ctx = { open: boolean; prefill: BookingPrefill; openBooking: (p?: BookingPrefill) => void; closeBooking: () => void }

const BookingCtx = createContext<Ctx | null>(null)

/** Permite abrir el panel de reserva desde cualquier botón del sitio */
export function BookingProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ open: boolean; prefill: BookingPrefill }>({ open: false, prefill: {} })
  return (
    <BookingCtx.Provider
      value={{
        ...state,
        openBooking: (prefill = {}) => setState({ open: true, prefill }),
        closeBooking: () => setState((s) => ({ ...s, open: false })),
      }}
    >
      {children}
    </BookingCtx.Provider>
  )
}

export function useBooking() {
  const ctx = useContext(BookingCtx)
  if (!ctx) throw new Error('useBooking debe usarse dentro de BookingProvider')
  return ctx
}
