import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { L, Lang } from '../data/site'

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (l: L) => string }
const LangCtx = createContext<Ctx | null>(null)

function initialLang(): Lang {
  try {
    const saved = localStorage.getItem('mb-lang')
    if (saved === 'es' || saved === 'en') return saved
  } catch { /* almacenamiento bloqueado */ }
  return navigator.language?.toLowerCase().startsWith('es') ? 'es' : 'en'
}

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>(initialLang)
  useEffect(() => {
    document.documentElement.lang = lang
    try { localStorage.setItem('mb-lang', lang) } catch { /* sin almacenamiento */ }
  }, [lang])
  return <LangCtx.Provider value={{ lang, setLang, t: (l) => l[lang] }}>{children}</LangCtx.Provider>
}

export function useLang() {
  const ctx = useContext(LangCtx)
  if (!ctx) throw new Error('useLang debe usarse dentro de LangProvider')
  return ctx
}
