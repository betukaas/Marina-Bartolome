/** Lenguaje de movimiento compartido: mismas curvas y duraciones en todo el sitio. */
export const EASE_OUT = [0.16, 1, 0.3, 1] as const      // salida larga y suave (revelados)
export const EASE_IN_OUT = [0.76, 0, 0.24, 1] as const  // cortinas y máscaras

export const DUR = { fast: 0.45, base: 0.9, slow: 1.4 }

export const viewportOnce = { once: true, margin: '0px 0px -12% 0px' } as const
