import { GEO } from '../data/site'

/**
 * Hora de la puesta de sol (algoritmo de la ecuación del amanecer de NOAA/Wikipedia).
 * Precisión de ±1–2 minutos, suficiente para sugerir una hora de reserva.
 */
const RAD = Math.PI / 180

/** Fecha (año, mes, día) en la zona horaria del restaurante */
export function localYMD(d: Date) {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: GEO.timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d)
  const [y, m, day] = parts.split('-').map(Number)
  return { y, m, d: day }
}

export function sunsetFor(y: number, m: number, d: number, lat = GEO.lat, lng = GEO.lng): Date {
  const jDate = Date.UTC(y, m - 1, d, 12) / 864e5 + 2440587.5
  const n = Math.round(jDate - 2451545.0 + 0.0008)
  const jStar = n - lng / 360
  const M = (357.5291 + 0.98560028 * jStar) % 360
  const C = 1.9148 * Math.sin(M * RAD) + 0.02 * Math.sin(2 * M * RAD) + 0.0003 * Math.sin(3 * M * RAD)
  const lambda = (M + C + 180 + 102.9372) % 360
  const jTransit = 2451545.0 + jStar + 0.0053 * Math.sin(M * RAD) - 0.0069 * Math.sin(2 * lambda * RAD)
  const sinDec = Math.sin(lambda * RAD) * Math.sin(23.4397 * RAD)
  const cosDec = Math.cos(Math.asin(sinDec))
  const cosW0 = (Math.sin(-0.833 * RAD) - Math.sin(lat * RAD) * sinDec) / (Math.cos(lat * RAD) * cosDec)
  const jSet = jTransit + Math.acos(cosW0) / RAD / 360
  return new Date((jSet - 2440587.5) * 864e5)
}

/** "18:21" en la hora de Isla Mujeres */
export const hhmm = (d: Date) =>
  new Intl.DateTimeFormat('en-GB', { timeZone: GEO.timeZone, hour: '2-digit', minute: '2-digit', hour12: false }).format(d)

/** Hora sugerida de llegada: una hora antes del atardecer, redondeada a cuartos de hora y dentro del horario de reservas */
export function suggestedArrival(sunset: Date, first = '11:00', last = '19:30') {
  const [h, m] = hhmm(sunset).split(':').map(Number)
  let mins = h * 60 + m - 60
  mins = Math.floor(mins / 15) * 15
  const toMin = (s: string) => Number(s.slice(0, 2)) * 60 + Number(s.slice(3))
  mins = Math.min(Math.max(mins, toMin(first)), toMin(last))
  return `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`
}

/** Próximos atardeceres a partir de hoy; si el de hoy ya pasó, empieza mañana */
export function upcomingSunsets(count = 4, now = new Date()) {
  const out: { date: Date; sunset: Date; isToday: boolean }[] = []
  const { y, m, d } = localYMD(now)
  for (let i = 0; out.length < count && i < count + 1; i++) {
    const day = new Date(Date.UTC(y, m - 1, d + i, 17))
    const ymd = localYMD(day)
    const sunset = sunsetFor(ymd.y, ymd.m, ymd.d)
    if (i === 0 && sunset < now) continue
    out.push({ date: day, sunset, isToday: i === 0 })
  }
  return out
}
