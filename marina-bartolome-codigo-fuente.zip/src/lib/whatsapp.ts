import { CONTACT, type Lang } from '../data/site'

export type Booking = {
  name?: string
  guests?: string
  date?: string
  time?: string
  occasion?: string
  allergies?: string
  notes?: string
  /** Llegada por mar: tipo y nombre de la embarcación, eslora y si necesita amarre */
  boat?: string
}

/**
 * Mensaje de reservación que llega al WhatsApp del restaurante.
 * Sin datos, sale como plantilla con los campos en blanco para que el cliente solo complete.
 */
export function bookingMessage(lang: Lang, b: Booking = {}) {
  const es = lang === 'es'
  const v = (x?: string) => (x?.trim() ? ` ${x.trim()}` : ' ')
  return [
    es ? 'Hola Marina Bartolomé 👋 Me gustaría reservar una mesa:' : 'Hello Marina Bartolomé 👋 I’d like to book a table:',
    `👤 ${es ? 'Nombre' : 'Name'}:${v(b.name)}`,
    `👥 ${es ? 'Personas' : 'Guests'}:${v(b.guests)}`,
    `📅 ${es ? 'Fecha' : 'Date'}:${v(b.date)}`,
    `🕐 ${es ? 'Hora' : 'Time'}:${v(b.time)}`,
    `🎉 ${es ? 'Ocasión' : 'Occasion'}:${v(b.occasion)}`,
    `⚠️ ${es ? 'Alergias' : 'Allergies'}:${v(b.allergies)}`,
    `📝 ${es ? 'Comentarios' : 'Notes'}:${v(b.notes)}`,
    // Todos los mensajes llevan la pregunta del yate: con datos si el formulario los dio, en blanco si no
    b.boat
      ? `⛵ ${es ? 'Llegada por mar' : 'Arriving by sea'}: ${b.boat}`
      : `⛵ ${es ? '¿Llegas en yate o lancha? Nombre y eslora' : 'Arriving by yacht or boat? Name and length'}: `,
    es ? '¡Gracias!' : 'Thank you!',
  ].join('\n')
}

export type EventRequest = { type?: string; guests?: string; date?: string; details?: string }

/** Mensaje para cotizar un evento o grupo. También lleva la pregunta del yate. */
export function eventMessage(lang: Lang, e: EventRequest = {}) {
  const es = lang === 'es'
  const v = (x?: string) => (x?.trim() ? ` ${x.trim()}` : ' ')
  return [
    es ? 'Hola Marina Bartolomé 👋 Me gustaría organizar un evento:' : 'Hello Marina Bartolomé 👋 I’d like to plan an event:',
    `🎉 ${es ? 'Tipo de evento' : 'Event type'}:${v(e.type)}`,
    `👥 ${es ? 'Personas (aprox.)' : 'Guests (approx.)'}:${v(e.guests)}`,
    `📅 ${es ? 'Fecha' : 'Date'}:${v(e.date)}`,
    `📝 ${es ? 'Detalles' : 'Details'}:${v(e.details)}`,
    `⛵ ${es ? '¿Llegan en yate o lancha? Nombre y eslora' : 'Arriving by yacht or boat? Name and length'}: `,
    es ? '¡Gracias!' : 'Thank you!',
  ].join('\n')
}

/** Enlace wa.me que abre la conversación del restaurante con el texto ya escrito. */
export function waLink(text: string) {
  if (!CONTACT.whatsapp) return null
  return `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(text)}`
}

/** Enlace rápido para cualquier botón de WhatsApp: abre con la plantilla de reservación. */
export const waBookingLink = (lang: Lang) => waLink(bookingMessage(lang))
