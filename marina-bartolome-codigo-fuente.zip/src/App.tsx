import { MotionConfig } from 'motion/react'
import { useCallback, useState } from 'react'
import { BookingDrawer } from './components/BookingDrawer'
import { Favorites } from './components/Favorites'
import { MobileBar } from './components/MobileBar'
import { Cursor } from './components/Cursor'
import { Events } from './components/Events'
import { Experience } from './components/Experience'
import { FloatingWhatsApp } from './components/FloatingWhatsApp'
import { Footer } from './components/Footer'
import { Header } from './components/Header'
import { Hero } from './components/Hero'
import { Intro } from './components/Intro'
import { Manifesto } from './components/Manifesto'
import { MenuOverlay } from './components/MenuOverlay'
import { Privacy } from './components/Privacy'
import { Reviews } from './components/Reviews'
import { Sunset } from './components/Sunset'
import { Visit } from './components/Visit'
import { T } from './data/site'
import { BookingProvider } from './lib/booking'
import { LangProvider, useLang } from './lib/i18n'

function Site() {
  const { t } = useLang()
  const [ready, setReady] = useState(false)
  const [menu, setMenu] = useState<{ open: boolean; cat?: string }>({ open: false })
  const openMenu = useCallback((cat?: string) => setMenu({ open: true, cat }), [])
  const closeMenu = useCallback(() => setMenu((m) => ({ ...m, open: false })), [])
  const onIntroDone = useCallback(() => setReady(true), [])
  const [privacy, setPrivacy] = useState(false)
  const openPrivacy = useCallback(() => setPrivacy(true), [])
  const closePrivacy = useCallback(() => setPrivacy(false), [])

  return (
    <>
      <a className="skip-link" href="#contenido">{t(T.skipToContent)}</a>
      <Intro onDone={onIntroDone} />
      <Cursor />
      <Header ready={ready} onMenu={() => openMenu()} />
      <main id="contenido">
        <Hero ready={ready} onMenu={() => openMenu()} />
        <Favorites onMenu={openMenu} />
        <Manifesto />
        <Sunset />
        <Experience />
        <Events />
        <Reviews />
        <Visit onPrivacy={openPrivacy} />
      </main>
      <Footer onPrivacy={openPrivacy} />
      <FloatingWhatsApp />
      <MenuOverlay open={menu.open} initial={menu.cat} onClose={closeMenu} />
      <Privacy open={privacy} onClose={closePrivacy} />
      <BookingDrawer onPrivacy={openPrivacy} />
      <MobileBar onMenu={() => openMenu()} />
    </>
  )
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <LangProvider>
        <BookingProvider>
          <Site />
        </BookingProvider>
      </LangProvider>
    </MotionConfig>
  )
}
