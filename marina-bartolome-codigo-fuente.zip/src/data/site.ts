/**
 * Contenido central del sitio de Marina Bartolomé.
 *
 * Lo que el restaurante cambia seguido (carta y precios, favoritos, reseñas, contacto,
 * horario, redes, fotos y textos principales) vive en src/content/*.json y se edita
 * desde el panel privado /admin. Este archivo une esos datos con el resto del sitio.
 * Los componentes solo leen de aquí.
 *
 * Fuentes de los datos:
 * - Ficha de Google Maps: dirección, horario, teléfono.
 * - Perfil de Instagram @marina_bartolomeisla: descripción, enlaces.
 * - Carta oficial del restaurante (English Menu, PDF de 4 páginas): platillos y precios.
 * - WhatsApp de reservaciones: confirmado por el restaurante.
 *
 * `null` significa "dato no confirmado". La interfaz muestra "Por confirmar"
 * en lugar de inventarlo.
 */

import carta from '../content/carta.json'
import favoritos from '../content/favoritos.json'
import fotos from '../content/fotos.json'
import negocio from '../content/negocio.json'
import resenas from '../content/resenas.json'
import textos from '../content/textos.json'

export type Lang = 'es' | 'en'
export type L = Record<Lang, string>
const l = (es: string, en: string): L => ({ es, en })

/** Muestra los marcadores "Por confirmar". Cámbialo a false cuando todo esté confirmado. */
export const SHOW_PENDING_MARKERS = false

/**
 * Dominio final del sitio, sin diagonal al final (p. ej. 'https://marinabartolome.com').
 * Al ponerlo, la compilación agrega la URL canónica, las imágenes absolutas para redes
 * sociales, el sitemap.xml y la URL en los datos para Google.
 */
export const SITE_URL: string | null = null

/** Precios tomados de la carta oficial en PDF (English Menu, 4 páginas). */
export const PRICES_CONFIRMED = true

/* -------------------------------------------------------------------------- */
/* Imágenes                                                                   */
/* -------------------------------------------------------------------------- */

export type Img = {
  /** Prefijo del archivo en public/images (se generan con scripts/optimize-images.py) */
  name: string
  widths: number[]
  width: number
  height: number
  alt: L
}

export const IMG = {
  fachada: { name: 'fachada', widths: [640, 1017], width: 1017, height: 1125, alt: l('Fachada de Marina Bartolomé con su muelle de madera sobre el agua turquesa', 'Marina Bartolomé façade with its wooden dock over turquoise water') },
  fachadaPanorama: { name: 'fachada-panorama', widths: [800, 1017], width: 1017, height: 610, alt: l('Marina Bartolomé vista desde el muelle', 'Marina Bartolomé seen from the dock') },
  mesa: { name: 'mesa', widths: [640, 1107], width: 1107, height: 1452, alt: l('Mesa en el muelle con pulpo, pescado tikinxic, camarones, coctel de camarón y bebidas', 'Dockside table with octopus, tikinxic fish, shrimp, shrimp cocktail and drinks') },
  pulpo: { name: 'pulpo', widths: [750], width: 750, height: 440, alt: l('Pulpo a la brasa con puré, elote asado y cebolla morada', 'Grilled octopus with mashed potatoes, grilled corn and pickled red onion') },
  langosta: { name: 'langosta', widths: [640, 862], width: 862, height: 1125, alt: l('Cola de langosta al mojo de ajo con ensalada, puré y elote', 'Garlic lobster tail with salad, mashed potatoes and corn') },
  torre: { name: 'torre', widths: [640, 1098], width: 1098, height: 1453, alt: l('Purple Spritz junto a una torre de atún y camarón frente a la marina', 'Purple Spritz next to a tuna and shrimp stack by the marina') },
  coctel: { name: 'coctel', widths: [500], width: 500, height: 680, alt: l('Purple Spritz de flor de mariposa con limón', 'Butterfly-pea Purple Spritz with lemon') },
  portada: { name: 'portada', widths: [640, 1133], width: 1133, height: 1253, alt: l('Marina Bartolomé desde el muelle: restaurante, terraza sobre el agua y lancha amarrada', 'Marina Bartolomé from the dock: restaurant, waterfront terrace and a moored boat') },
  portadaPanorama: { name: 'portada-panorama', widths: [800, 1133], width: 1133, height: 670, alt: l('Marina Bartolomé desde el muelle', 'Marina Bartolomé from the dock') },
  pescado: { name: 'pescado', widths: [640, 1100], width: 1100, height: 1444, alt: l('Pescado entero zarandeado en tabla, con arroz, frijoles, pico de gallo y limón asado', 'Whole zarandeado-style fish on a board with rice, beans, pico de gallo and grilled lemon') },
  stack: { name: 'stack', widths: [860], width: 860, height: 860, alt: l('Seafood stack de atún, camarón, mango y aguacate', 'Seafood stack with tuna, shrimp, mango and avocado') },
  camarones: { name: 'camarones', widths: [420], width: 420, height: 260, alt: l('Camarones zarandeados en adobo rojo', 'Zarandeado-style shrimp in red adobo') },
  ginPepino: { name: 'gin-pepino', widths: [347], width: 347, height: 560, alt: l('Coctel con listón de pepino y hielo', 'Cocktail with cucumber ribbon and ice') },
  atardecer: { name: 'atardecer', widths: [640, 1077], width: 1077, height: 1351, alt: l('Atardecer dorado sobre el muelle de Marina Bartolomé con un yate amarrado', 'Golden sunset over the Marina Bartolomé dock with a moored yacht') },
  atardecerPanorama: { name: 'atardecer-panorama', widths: [800, 1077], width: 1077, height: 670, alt: l('Atardecer sobre el muelle y la bahía', 'Sunset over the dock and the bay') },
} satisfies Record<string, Img>

/** Fotos cambiadas desde el panel: si traen descripción nueva, reemplaza la original. */
type PhotoKey = keyof typeof fotos
const PHOTO_GROUPS: Record<PhotoKey, (keyof typeof IMG)[]> = {
  portada: ['portada', 'portadaPanorama'],
  fachada: ['fachada', 'fachadaPanorama'],
  atardecer: ['atardecer', 'atardecerPanorama'],
  mesa: ['mesa'], pulpo: ['pulpo'], camarones: ['camarones'], pescado: ['pescado'], langosta: ['langosta'],
  stack: ['stack'], torre: ['torre'], coctel: ['coctel'], ginPepino: ['ginPepino'],
}
for (const [key, photo] of Object.entries(fotos) as [PhotoKey, (typeof fotos)[PhotoKey]][]) {
  if (photo.file && photo.alt.es.trim()) for (const name of PHOTO_GROUPS[key]) IMG[name].alt = { es: photo.alt.es, en: photo.alt.en || photo.alt.es }
}

/**
 * Video de portada opcional (p. ej. generado con Higgsfield y aprobado por el cliente).
 * Archivos en public/video/. Mientras sea null, la portada usa la fotografía.
 */
export const HERO_VIDEO: { mp4: string; webm?: string } | null = null

/* -------------------------------------------------------------------------- */
/* Datos del restaurante                                                       */
/* -------------------------------------------------------------------------- */

export const BRAND = {
  name: 'Marina Bartolomé',
  /** Tal como aparece en el logotipo oficial */
  descriptor: l('Restaurante · Bar · Marina', 'Restaurant · Bar · Marina'),
  place: 'Isla Mujeres Centro, Quintana Roo',
}

const C = negocio.contact
const digits = (x: string) => x.replace(/\D/g, '')
/** Búsqueda de Google Maps armada con el nombre y la dirección del panel */
const MAPS_Q = encodeURIComponent(`Marina Bartolomé, ${C.address.split(",")[0]}, Isla Mujeres`)

export const CONTACT = {
  /** Teléfono fijo, tal como se muestra */
  phone: (C.phone || null) as string | null,
  /** Mismo número en formato internacional para enlaces tel: */
  phoneIntl: (C.phone ? `+52${digits(C.phone).replace(/^52/, '')}` : null) as string | null,
  /** WhatsApp de reservaciones: solo dígitos con lada */
  whatsapp: (C.whatsapp ? digits(C.whatsapp) : null) as string | null,
  whatsappDisplay: C.whatsapp,
  email: null as string | null,
  address: C.address,
  locality: C.locality,
  /** Ficha de Google Maps compartida por el restaurante */
  mapsUrl: C.mapsUrl,
  /** Mapa embebido (sin API key). Se desactiva en la vista previa de Artifact, que no permite iframes. */
  mapsEmbed: `https://www.google.com/maps?q=${MAPS_Q}&z=17&output=embed`,
  /** Vista alejada: toda la isla, el ferry y Cancún, para ubicarse */
  mapsEmbedIsla: `https://www.google.com/maps?q=${MAPS_Q}&z=13&output=embed`,
  /** Misma ubicación en vista satelital (desde arriba) */
  mapsEmbedSat: `https://www.google.com/maps?q=${MAPS_Q}&t=k&z=18&output=embed`,
  /** Abre la ruta en Google Maps desde la ubicación del visitante */
  directionsUrl: `https://www.google.com/maps/dir/?api=1&destination=${MAPS_Q}`,
  takesReservations: true,
  /** Carta oficial en PDF o web. PENDIENTE */
  menuUrl: null as string | null,
}

export const HOURS: { days: L; hours: string }[] | null = negocio.hours.length ? negocio.hours : null
/** Ubicación (Plus Code 7733+QW Isla Mujeres) para calcular el atardecer */
export const GEO = { lat: 21.2544, lng: -86.7452, timeZone: 'America/Cancun' }

/** Formas de pago confirmadas por el restaurante */
export const PAYMENTS = negocio.payments

/** Promoción publicada en Instagram. Las condiciones se consultan con el restaurante. */
export const LOCALS_OFFER = negocio.localsOffer

export type Review = {
  author: string
  rating: number
  /** Texto original de Google, sin traducir ni editar */
  text: L
  /** Idioma original de la reseña */
  lang: 'es' | 'en'
  badge?: string
  /** Calificó Comida 5 · Servicio 5 · Ambiente 5 */
  scores?: boolean
  when?: string
}
/** Reseñas copiadas tal cual de Google Maps, en su idioma original. Nunca inventar reseñas. */
export const REVIEWS: Review[] = resenas.reviews.map((r) => ({
  ...r,
  lang: r.lang === 'en' ? 'en' : 'es',
  badge: r.badge || undefined,
  when: r.when || undefined,
  text: { es: r.text, en: r.text },
}))

/** Límites del selector de hora en el formulario de reservas */
export const BOOKING_HOURS = negocio.booking

export const SOCIAL: { label: string; handle: string; url: string | null }[] = negocio.social.map((x) => ({ ...x, url: x.url || null }))

/* -------------------------------------------------------------------------- */
/* Carta                                                                      */
/* -------------------------------------------------------------------------- */

export type MenuItem = {
  name: L
  desc?: L
  price: string
  /** Marcado con estrella ("Star dish") en la carta */
  star?: boolean
  /** Marcado con palmera ("Local cuisine") en la carta */
  local?: boolean
  /** Nota corta: temporada, premio, etc. */
  note?: L
}
export type MenuGroup = { title: L; note?: L; local?: boolean; items: MenuItem[] }
export type MenuSection = { id: string; title: L; intro: L; img: Img; groups: MenuGroup[] }

/** Foto del panel → imagen del sitio (nombre de la clave en IMG) */
const photo = (key: string): Img => IMG[(key in IMG ? key : 'mesa') as keyof typeof IMG]

/** Carta oficial (English Menu, PDF de 4 páginas). Precios en MXN con IVA incluido. Se edita en el panel. */
/** El panel puede guardar campos opcionales vacíos: se limpian para que no se muestren huecos. */
type RawL = { es?: string; en?: string } | null | undefined
const opt = (x: RawL): L | undefined => (x?.es?.trim() ? { es: x.es, en: x.en?.trim() ? x.en : x.es } : undefined)
type RawItem = { name: L; desc?: RawL; price: string; star?: boolean; local?: boolean; note?: RawL }
const item = (it: RawItem): MenuItem => ({ name: it.name, desc: opt(it.desc), price: it.price, star: !!it.star, local: !!it.local, note: opt(it.note) })

export const MENU: MenuSection[] = carta.sections.map(({ photo: p, groups, ...section }) => ({
  ...section,
  img: photo(p),
  groups: (groups as { title: L; note?: RawL; local?: boolean; items: RawItem[] }[]).map((g) => ({
    title: g.title, note: opt(g.note), local: !!g.local, items: g.items.map(item),
  })),
}))

/** Favoritos de la casa: platillos con ★ en la carta oficial y foto propia */
export const FAVORITES: { item: MenuItem; img: Img; menuId: string }[] = favoritos.dishes.map(({ photo: p, menuId, ...dish }) => ({
  item: item(dish),
  img: photo(p),
  menuId,
}))

/* -------------------------------------------------------------------------- */
/* Textos de interfaz                                                          */
/* -------------------------------------------------------------------------- */

const BASE_T = {
  nav: {
    cuisine: l('La cocina', 'Cuisine'),
    experience: l('Experiencia', 'Experience'),
    events: l('Eventos', 'Events'),
    visit: l('Visítanos', 'Visit'),
    reserve: l('Reservar', 'Book a table'),
    menu: l('Menú', 'Menu'),
    close: l('Cerrar', 'Close'),
  },
  hero: {
    eyebrow: l('Mariscos · Isla Mujeres Centro', 'Seafood · Downtown Isla Mujeres'),
    line1: l('El Caribe,', 'The Caribbean,'),
    line2: l('servido.', 'served.'),
    sub: l(
      'Restaurante de mariscos, bar y marina sobre el agua turquesa de Isla Mujeres.',
      'Seafood restaurant, bar and marina over the turquoise water of Isla Mujeres.',
    ),
    ctaMenu: l('Descubrir el menú', 'Discover the menu'),
    ctaReserve: l('Reservar mesa', 'Book a table'),
    scroll: l('Desliza', 'Scroll'),
  },
  manifesto: {
    eyebrow: l('Restaurante · Bar · Marina', 'Restaurant · Bar · Marina'),
    text: l(
      'Come mariscos frente al mar. Pesca del día, ostiones, drinks y atardeceres, sobre el muelle de Isla Mujeres Centro.',
      'Seafood by the sea. Catch of the day, oysters, drinks and sunsets, on the dock in downtown Isla Mujeres.',
    ),
  },
  cuisine: {
    eyebrow: l('La cocina', 'The kitchen'),
    title1: l('Del agua', 'From the water'),
    title2: l('a la mesa', 'to the table'),
    lead: l(
      'Pulpo, camarón, langosta, pescado entero, ceviches y coctelería. Explora la carta por capítulos.',
      'Octopus, shrimp, lobster, whole fish, ceviches and cocktails. Explore the menu chapter by chapter.',
    ),
    explore: l('Explorar el menú completo', 'Explore the full menu'),
  },
  experience: {
    eyebrow: l('La experiencia', 'The experience'),
    title1: l('Comer', 'Dining'),
    title2: l('sobre el agua', 'over the water'),
    blocks: [
      { title: l('El muelle', 'The dock'), text: l('Mesas sobre la cubierta de madera, a la orilla del agua, con las embarcaciones de la marina a la vista y el atardecer de frente.', 'Tables on the wooden deck at the water’s edge, with the marina’s boats in view and the sunset straight ahead.') },
      { title: l('La mesa', 'The table'), text: l('Pesca del día, ostiones, pulpo y langosta para compartir al centro, servidos en vajilla artesanal y tablas de madera.', 'Catch of the day, oysters, octopus and lobster to share, served on handmade ceramics and wooden boards.') },
      { title: l('El bar', 'The bar'), text: l('Nuestra propia cerveza, una Session IPA, y coctelería de autor con mezcal, tequila y flores.', 'Our own Session IPA and signature cocktails with mezcal, tequila and flowers.') },
    ],
    storyTitle: l('Nuestra historia', 'Our story'),
    storyKicker: l('Una familia isleña', 'An island family'),
    story: [
      l(
        'Marina Bartolomé nació de una familia isleña que creció mirando este mar. Aquí aprendimos que la hospitalidad se hereda: se recibe a cada persona como a alguien de casa, con la mesa puesta y el mejor producto del día.',
        'Marina Bartolomé was born from an island family that grew up looking out at this sea. Here we learned that hospitality is inherited: every guest is welcomed like family, with the table set and the best catch of the day.',
      ),
      l(
        'Nos mueven valores sencillos y firmes: el respeto por el mar y por quienes lo trabajan, la honestidad en cada plato y el compromiso con la excelencia, del muelle a la cocina y de la cocina a tu mesa.',
        'We are guided by simple, steady values: respect for the sea and for those who work it, honesty in every plate and a commitment to excellence, from the dock to the kitchen and from the kitchen to your table.',
      ),
      l(
        'Nuestra forma de contribuir es cuidar cada detalle de tu visita, para que te lleves algo más que una buena comida: una tarde en Isla Mujeres que quieras repetir.',
        'Our way of giving back is to care for every detail of your visit, so you leave with more than a good meal: an afternoon in Isla Mujeres you will want to repeat.',
      ),
    ],
    values: [
      l('Familia isleña', 'Island family'),
      l('Respeto por el mar', 'Respect for the sea'),
      l('Excelencia', 'Excellence'),
      l('Servicio de corazón', 'Heartfelt service'),
    ],
    storyPending: false,
  },
  visit: {
    eyebrow: l('Visítanos', 'Visit us'),
    title1: l('Te esperamos', 'We’ll save you'),
    title2: l('en el muelle', 'a seat by the water'),
    location: l('Ubicación', 'Location'),
    hours: l('Horario', 'Hours'),
    contact: l('Reservaciones', 'Reservations'),
    follow: l('Síguenos', 'Follow us'),
    maps: l('Cómo llegar', 'Get directions'),
    call: l('Llamar', 'Call'),
    reserveTitle: l('Reserva tu mesa', 'Book your table'),
    reserveLead: l(
      'Completa los datos y se abrirá WhatsApp con tu reservación lista para enviar.',
      'Fill in the details and WhatsApp will open with your booking ready to send.',
    ),
    occasion: l('Ocasión', 'Occasion'),
    occasions: [
      l('Sin ocasión especial', 'No special occasion'),
      l('Cumpleaños', 'Birthday'),
      l('Aniversario', 'Anniversary'),
      l('Cita romántica', 'Date night'),
      l('Celebración familiar', 'Family celebration'),
      l('Negocios', 'Business'),
    ],
    allergies: l('Alergias o restricciones', 'Allergies or dietary needs'),
    allergiesPh: l('Ej. mariscos, nueces, gluten. Déjalo vacío si no hay.', 'E.g. shellfish, nuts, gluten. Leave empty if none.'),
    preview: l('Así llegará tu mensaje', 'Your message will look like this'),
    bySea: l('¿Llegas en yate o lancha?', 'Arriving by yacht or boat?'),
    bySeaHint: l('Te apartamos lugar en nuestro muelle.', 'We’ll save you a spot at our dock.'),
    boatType: l('Tipo', 'Type'),
    boatTypes: [l('Yate', 'Yacht'), l('Lancha', 'Boat'), l('Velero', 'Sailboat'), l('Catamarán', 'Catamaran')],
    boatName: l('Nombre de la embarcación', 'Boat name'),
    boatNamePh: l('Ej. Sea Breeze', 'E.g. Sea Breeze'),
    boatLength: l('Eslora (pies)', 'Length (ft)'),
    boatDock: l('¿Necesitas amarre en el muelle?', 'Need to dock at our pier?'),
    yes: l('Sí', 'Yes'),
    no: l('No', 'No'),
    waHint: l('Se abre WhatsApp con el mensaje listo. Solo presiona enviar.', 'WhatsApp opens with the message ready. Just press send.'),
    whatsapp: l('WhatsApp', 'WhatsApp'),
    phone: l('Teléfono', 'Phone'),
    name: l('Nombre', 'Name'),
    guests: l('Personas', 'Guests'),
    date: l('Fecha', 'Date'),
    time: l('Hora', 'Time'),
    notes: l('Comentarios', 'Notes'),
    notesPh: l('Mesa en el muelle, silla para bebé, llegamos en lancha…', 'Table on the dock, high chair, arriving by boat…'),
    openWa: l('Reservar por WhatsApp', 'Book via WhatsApp'),
    fab: l('Reservar', 'Book'),
    errName: l('Escribe tu nombre para la reservación.', 'Add your name for the booking.'),
    errDate: l('Elige una fecha de hoy en adelante.', 'Choose today or a later date.'),
    errTime: l('Elige una hora entre 11:00 y 19:30.', 'Choose a time between 11:00 and 19:30.'),
    copy: l('Copiar', 'Copy'),
    copied: l('Copiado', 'Copied'),
  },
  quick: {
    title: l('Reserva en segundos', 'Book in seconds'),
    guests: l('Personas', 'Guests'),
    date: l('Fecha', 'Date'),
    time: l('Hora', 'Time'),
    go: l('Reservar', 'Book'),
    hint: l('Se abre WhatsApp con tu reservación lista.', 'WhatsApp opens with your booking ready.'),
  },
  favorites: {
    eyebrow: l('Favoritos de la casa', 'House favorites'),
    title1: l('Lo que tienes', 'What you have'),
    title2: l('que probar aquí', 'to try here'),
    lead: l('Los platillos estrella de nuestra carta, servidos en tu mesa frente al mar.', 'The star dishes from our menu, served at your table by the sea.'),
    want: l('Reservar para probarlo', 'Book a table for it'),
    inMenu: l('Ver en la carta', 'See in menu'),
    note: l('Quiero probar', 'I’d like to try'),
    all: l('Ver toda la carta', 'See the full menu'),
    browse: l('Explora la carta', 'Browse the menu'),
  },
  booking: {
    open: l('Reservar mesa', 'Book a table'),
    cardTitle: l('¿Listo para venir?', 'Ready to come over?'),
    cardText: l('Reserva en menos de un minuto: llenas tus datos y nos llegan por WhatsApp.', 'Book in under a minute: fill in your details and they reach us on WhatsApp.'),
  },
  bar: {
    reserve: l('Reservar', 'Book'),
    menu: l('Menú', 'Menu'),
    route: l('Llegar', 'Directions'),
  },
  events: {
    eyebrow: l('Celebraciones y grupos', 'Celebrations & groups'),
    title1: l('Tu celebración,', 'Your celebration,'),
    title2: l('frente al mar', 'by the sea'),
    lead: l(
      'Cumpleaños, aniversarios, grupos de amigos o la tripulación de tu yate: cuéntanos qué tienes en mente y lo organizamos contigo por WhatsApp.',
      'Birthdays, anniversaries, groups of friends or your yacht crew: tell us what you have in mind and we’ll plan it with you on WhatsApp.',
    ),
    typeLabel: l('¿Qué celebras?', 'What are you celebrating?'),
    types: [
      l('Cumpleaños', 'Birthday'),
      l('Aniversario', 'Anniversary'),
      l('Grupo de amigos', 'Group of friends'),
      l('Grupo de tour', 'Tour group'),
      l('Grupo en yate', 'Yacht group'),
      l('Otro', 'Other'),
    ],
    guests: l('Personas (aprox.)', 'Guests (approx.)'),
    date: l('Fecha', 'Date'),
    details: l('Cuéntanos más (opcional)', 'Tell us more (optional)'),
    detailsHint: l('Hora, pastel, decoración, menú especial…', 'Time, cake, decoration, special menu…'),
    cta: l('Planear por WhatsApp', 'Plan it on WhatsApp'),
    note: l('Te respondemos por WhatsApp para confirmar disponibilidad y detalles.', 'We’ll reply on WhatsApp to confirm availability and details.'),
  },
  sunset: {
    eyebrow: l('Reserva para el atardecer', 'Book for sunset'),
    today: l('El sol se pone hoy a las', 'Today the sun sets at'),
    tomorrow: l('Mañana el sol se pone a las', 'Tomorrow the sun sets at'),
    arrive: l('Llega a las {t} y mira el atardecer desde el muelle, con una copa en la mano.', 'Arrive at {t} and watch the sunset from the dock with a drink in hand.'),
    cta: l('Reservar para el atardecer', 'Book for sunset'),
    next: l('Próximos días', 'Next days'),
    note: l('Hora calculada para Isla Mujeres.', 'Time calculated for Isla Mujeres.'),
    comment: l('Mesa para ver el atardecer', 'Table to watch the sunset'),
    useTime: l('Usar la hora del atardecer', 'Use sunset time'),
  },
  reviews: {
    eyebrow: l('Reseñas y ubicación', 'Reviews & location'),
    title1: l('Lo que dicen', 'What our'),
    title2: l('nuestros invitados', 'guests say'),
    read: l('Leer reseñas en', 'Read reviews on'),
    tripadvisor: l('Ver en', 'See us on'),
    write: l('Deja tu reseña', 'Leave a review'),
    find: l('Encuéntranos en el malecón de Isla Mujeres Centro', 'Find us on the waterfront in downtown Isla Mujeres'),
    open: l('Abrir en Google Maps', 'Open in Google Maps'),
    directions: l('Cómo llegar', 'Get directions'),
    viewMap: l('Calles', 'Streets'),
    viewIsla: l('Isla', 'Island'),
    viewSat: l('Satélite', 'Satellite'),
    source: l('Reseña de Google', 'Google review'),
    original: l('Reseña original en inglés', 'Original review in Spanish'),
    scores: l('Comida 5 · Servicio 5 · Ambiente 5', 'Food 5 · Service 5 · Atmosphere 5'),
    more: l('Leer completa', 'Read more'),
    less: l('Ver menos', 'Show less'),
    pause: l('Pausar reseñas', 'Pause reviews'),
    play: l('Reanudar reseñas', 'Play reviews'),
    prev: l('Reseña anterior', 'Previous review'),
    next: l('Siguiente reseña', 'Next review'),
    empty: l('¿Ya nos visitaste? Cuéntanos cómo te fue.', 'Have you visited us? Tell us how it went.'),
  },
  extras: {
    payments: l('Formas de pago', 'Payment'),
    locals: l('{p} % para isleños', '{p}% off for islanders'),
    localsNote: l('Descuento para residentes de Isla Mujeres. Pregunta por las condiciones al reservar.', 'Discount for Isla Mujeres residents. Ask about the conditions when booking.'),
  },
  privacy: {
    link: l('Aviso de privacidad', 'Privacy notice'),
    consent: l('Al enviar tu reservación aceptas nuestro', 'By sending your booking you accept our'),
    title: l('Aviso de privacidad', 'Privacy notice'),
    updated: l('Última actualización: octubre de 2026', 'Last updated: October 2026'),
    sections: [
      {
        h: l('Responsable', 'Data controller'),
        p: l(
          'Marina Bartolomé, con domicilio en Av. Rueda Medina 1667, Centro, Supmza. 001, 77400 Isla Mujeres, Quintana Roo, México, es responsable del tratamiento de los datos personales que nos compartes.',
          'Marina Bartolomé, located at Av. Rueda Medina 1667, Centro, Supmza. 001, 77400 Isla Mujeres, Quintana Roo, Mexico, is responsible for the personal data you share with us.',
        ),
      },
      {
        h: l('Datos que recabamos', 'Data we collect'),
        p: l(
          'Para tu reservación: nombre, número de personas, fecha, hora, ocasión, alergias o restricciones alimentarias, comentarios y, si llegas por mar, los datos de tu embarcación. Las alergias se consideran información sensible y solo las usamos para cuidar tu salud durante tu visita.',
          'For your booking: name, number of guests, date, time, occasion, allergies or dietary restrictions, notes and, if arriving by sea, your boat details. Allergies are considered sensitive information and we only use them to look after your health during your visit.',
        ),
      },
      {
        h: l('Cómo los recibimos', 'How we receive them'),
        p: l(
          'Este sitio no guarda tus datos. El formulario solo prepara un mensaje en tu dispositivo, y nos llega únicamente cuando tú decides enviarlo por WhatsApp. El sitio recuerda en tu navegador el idioma que elegiste.',
          'This website does not store your data. The form only prepares a message on your device, and it reaches us only when you choose to send it via WhatsApp. The site remembers your chosen language in your browser.',
        ),
      },
      {
        h: l('Finalidades', 'Purposes'),
        p: l(
          'Confirmar y administrar tu reservación, preparar tu mesa y atender tus alergias o solicitudes especiales. No usamos tus datos para publicidad ni los vendemos o compartimos con terceros, salvo obligación legal.',
          'To confirm and manage your booking, prepare your table and attend to your allergies or special requests. We do not use your data for advertising, nor sell or share it with third parties, except where required by law.',
        ),
      },
      {
        h: l('Tus derechos (ARCO)', 'Your rights'),
        p: l(
          'Puedes acceder, rectificar, cancelar u oponerte al uso de tus datos, o revocar tu consentimiento, escribiéndonos por WhatsApp al +52 998 181 3378 o llamando al 998 234 2257.',
          'You may access, correct, delete or object to the use of your data, or withdraw your consent, by messaging us on WhatsApp at +52 998 181 3378 or calling 998 234 2257.',
        ),
      },
      {
        h: l('Cambios', 'Changes'),
        p: l('Cualquier cambio a este aviso se publicará en esta misma página.', 'Any change to this notice will be published on this page.'),
      },
    ],
  },
  menu: {
    title: l('Menú', 'Menu'),
    star: l('Platillo estrella', 'Star dish'),
    full: l('Ver la carta en PDF', 'See the PDF menu'),
    pricesPending: l('Precios por confirmar', 'Prices to be confirmed'),
    legal: l(
      'Precios en pesos mexicanos con IVA (16 %) incluido. El consumo de alimentos crudos es responsabilidad del cliente.',
      'Prices in Mexican pesos, 16% tax included. Consumption of raw foods is at the customer’s own discretion.',
    ),
    spirits: l(
      'Destilados por copa (45 ml): vodka, gin, tequila (Don Julio, Patrón, 1800, Herradura y más), mezcal, ron, whisky, brandy, cognac y licores. Pregunta por la carta completa.',
      'Spirits by the pour (45 ml): vodka, gin, tequila (Don Julio, Patrón, 1800, Herradura and more), mezcal, rum, whisky, brandy, cognac and liqueurs. Ask for the full list.',
    ),
    local: l('Cocina local', 'Local cuisine'),
  },
  footer: {
    rights: l('Todos los derechos reservados.', 'All rights reserved.'),
    top: l('Volver arriba', 'Back to top'),
    follow: l('Síguenos', 'Follow us'),
  },
  pending: l('Por confirmar', 'To be confirmed'),
  skip: l('Saltar intro', 'Skip intro'),
  skipToContent: l('Ir al contenido', 'Skip to content'),
}

/** Copia los textos editados en el panel sobre los de base. Un texto vacío conserva el original. */
function override<V>(base: V, patch: unknown): V {
  if (patch == null) return base
  if (typeof base === 'string') return (typeof patch === 'string' && patch.trim() ? patch : base) as V
  if (Array.isArray(base)) return (Array.isArray(patch) && patch.length ? patch.map((p, i) => override(base[i] ?? base[0], p)) : base) as V
  if (typeof base === 'object' && base && typeof patch === 'object') {
    const out = { ...base } as Record<string, unknown>
    for (const k of Object.keys(out)) out[k] = override(out[k], (patch as Record<string, unknown>)[k])
    return out as V
  }
  return base
}

export const T = override(BASE_T, textos)
