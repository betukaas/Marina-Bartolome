/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** "1" al compilar la vista previa de Artifact (sin iframes) */
  readonly VITE_ARTIFACT?: string
}
