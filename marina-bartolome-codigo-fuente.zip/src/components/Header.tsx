import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'motion/react'
import { useEffect, useState } from 'react'
import { SOCIAL, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { FacebookIcon, InstagramIcon } from './Icons'
import { useLang } from '../lib/i18n'
import { EASE_IN_OUT, EASE_OUT } from '../lib/motion'

const BASE = import.meta.env.BASE_URL
const IG = SOCIAL.find((s) => s.label === 'Instagram')?.url
const FB = SOCIAL.find((s) => s.label === 'Facebook')?.url
const LINKS = [
  { href: '#cocina', label: T.nav.cuisine },
  { href: '#experiencia', label: T.nav.experience },
  { href: '#eventos', label: T.nav.events },
  { href: '#visita', label: T.nav.visit },
]

export function Header({ onMenu, ready }: { onMenu: () => void; ready: boolean }) {
  const { t, lang, setLang } = useLang()
  const { openBooking } = useBooking()
  const { scrollY } = useScroll()
  const [solid, setSolid] = useState(false)
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('')

  useMotionValueEvent(scrollY, 'change', (y) => {
    // El encabezado queda siempre visible para que "Reservar" esté a un clic en todo momento
    setSolid(y > 60)
  })

  // Sección activa para el indicador de navegación
  useEffect(() => {
    const ids = LINKS.map((l) => l.href.slice(1))
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive('#' + e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    )
    ids.forEach((id) => { const el = document.getElementById(id); if (el) io.observe(el) })
    return () => io.disconnect()
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', esc)
    return () => window.removeEventListener('keydown', esc)
  }, [open])

  const LangSwitch = (
    <div className="lang" role="group" aria-label="Idioma / Language">
      {(['es', 'en'] as const).map((l) => (
        <button key={l} type="button" aria-pressed={lang === l} onClick={() => setLang(l)}>{l.toUpperCase()}</button>
      ))}
    </div>
  )

  return (
    <>
      <motion.header
        className={`header ${solid ? 'is-solid' : ''} ${open ? 'is-open' : ''}`}
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: ready ? 0 : -100, opacity: ready ? 1 : 0 }}
        transition={{ duration: 0.8, ease: EASE_OUT, delay: ready && !solid ? 0.6 : 0 }}
      >
        <div className="header-in">
          <a href="#inicio" className="logo" aria-label="Marina Bartolomé">
            <img src={`${BASE}images/logo-perla-160.webp`} width={44} height={44} alt="" />
            <span className="logo-word"><small>Marina</small><b>Bartolomé</b></span>
          </a>
          <nav className="nav" aria-label="Principal">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} className={active === l.href ? 'is-active' : ''}>{t(l.label)}</a>
            ))}
            <button type="button" className="nav-menu-btn" onClick={onMenu}>{t(T.nav.menu)}</button>
          </nav>
          <div className="header-actions">
            {IG && <a className="icon-link" href={IG} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><InstagramIcon /></a>}
            {LangSwitch}
            <button type="button" className="btn btn-gold btn-sm" onClick={() => openBooking()}><span>{t(T.nav.reserve)}</span></button>
            <button
              type="button"
              className="burger"
              aria-expanded={open}
              aria-controls="mobile-nav"
              aria-label={open ? t(T.nav.close) : t(T.nav.menu)}
              onClick={() => setOpen(!open)}
            >
              <span /><span />
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-nav"
            className="mobile-nav"
            initial={{ clipPath: 'inset(0% 0% 100% 0%)' }}
            animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
            exit={{ clipPath: 'inset(0% 0% 100% 0%)' }}
            transition={{ duration: 0.8, ease: EASE_IN_OUT }}
          >
            <nav aria-label="Móvil">
              {LINKS.map((l, i) => (
                <span className="mask-line" key={l.href}>
                  <motion.a
                    className="mask-inner"
                    href={l.href}
                    onClick={() => setOpen(false)}
                    initial={{ y: '110%' }}
                    animate={{ y: 0 }}
                    transition={{ duration: 0.9, ease: EASE_OUT, delay: 0.3 + i * 0.07 }}
                  >
                    {t(l.label)}
                  </motion.a>
                </span>
              ))}
              <motion.button type="button" className="btn btn-gold mobile-reserve" onClick={() => { setOpen(false); openBooking() }} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
                <span>{t(T.booking.open)}</span>
              </motion.button>
              <motion.button type="button" className="mobile-menu-link" onClick={() => { setOpen(false); onMenu() }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}>
                {t(T.hero.ctaMenu)} →
              </motion.button>
            </nav>
            <motion.div className="mobile-foot" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
              {LangSwitch}
              <div className="mobile-icons">
                {IG && <a className="icon-link" href={IG} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><InstagramIcon /></a>}
                {FB && <a className="icon-link" href={FB} target="_blank" rel="noopener noreferrer" aria-label="Facebook"><FacebookIcon /></a>}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
