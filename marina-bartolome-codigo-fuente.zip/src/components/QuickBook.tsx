import { useState, type MouseEvent } from 'react'
import { BOOKING_HOURS, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { bookingMessage, waLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

/** Barra de reserva rápida en la portada: personas, fecha y hora, directo a WhatsApp. */
export function QuickBook() {
  const { t, lang } = useLang()
  const { openBooking } = useBooking()
  const q = T.quick
  const today = new Date()
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1)
  const [f, setF] = useState({ guests: '2', date: iso(tomorrow), time: '14:00' })
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })

  const [y, m, d] = f.date.split('-').map(Number)
  const day = f.date ? new Date(y, m - 1, d).toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' }) : ''
  const href = waLink(bookingMessage(lang, { guests: f.guests, date: day, time: f.time }))
  const valid = f.date >= iso(today) && f.time >= BOOKING_HOURS.first && f.time <= BOOKING_HOURS.last

  // Si algo no cuadra, en lugar de enviar abre el formulario completo con lo que ya eligió
  const check = (e: MouseEvent) => { if (!valid) { e.preventDefault(); openBooking(f) } }

  return (
    <form className="quickbook" onSubmit={(e) => e.preventDefault()} aria-label={t(q.title)}>
      <label className="qb-field">
        <span>{t(q.guests)}</span>
        <select id="qb-guests" value={f.guests} onChange={set('guests')}>
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13+'].map((n) => <option key={n}>{n}</option>)}
        </select>
      </label>
      <label className="qb-field">
        <span>{t(q.date)}</span>
        <input id="qb-date" type="date" min={iso(today)} value={f.date} onChange={set('date')} />
      </label>
      <label className="qb-field">
        <span>{t(q.time)}</span>
        <input id="qb-time" type="time" step={900} min={BOOKING_HOURS.first} max={BOOKING_HOURS.last} value={f.time} onChange={set('time')} />
      </label>
      {href && (
        <a className="btn btn-wa qb-go" href={href} target="_blank" rel="noopener noreferrer" onClick={check}>
          <WhatsAppIcon size={18} /><span>{t(q.go)}</span>
        </a>
      )}
    </form>
  )
}
