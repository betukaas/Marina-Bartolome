import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from 'motion/react'
import { useRef } from 'react'
import { T } from '../data/site'
import { useLang } from '../lib/i18n'
import { Reveal } from './Reveal'

const BASE = import.meta.env.BASE_URL

function Word({ word, i, total, progress }: { word: string; i: number; total: number; progress: MotionValue<number> }) {
  const start = i / total
  const opacity = useTransform(progress, [start - 0.08, start + 0.04], [0.16, 1])
  return <motion.span style={{ opacity }}>{word} </motion.span>
}

/** Declaración de marca: las palabras se encienden al ritmo del desplazamiento. */
export function Manifesto() {
  const { t } = useLang()
  const reduce = useReducedMotion()
  const ref = useRef<HTMLParagraphElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.85', 'end 0.45'] })
  const words = t(T.manifesto.text).split(' ')
  const wheel = useTransform(scrollYProgress, [0, 1], [-40, 40])

  return (
    <section className="manifesto surface-pearl" id="manifiesto">
      <div className="wrap manifesto-grid">
        <Reveal className="manifesto-side">
          <motion.img src={`${BASE}images/logo-marino-160.webp`} width={88} height={88} alt="" style={{ rotate: reduce ? 0 : wheel }} />
          <p className="eyebrow eyebrow-dark">{t(T.manifesto.eyebrow)}</p>
        </Reveal>
        <p ref={ref} className="manifesto-text">
          {reduce ? t(T.manifesto.text) : words.map((w, i) => <Word key={i} word={w} i={i} total={words.length} progress={scrollYProgress} />)}
        </p>
      </div>
    </section>
  )
}
