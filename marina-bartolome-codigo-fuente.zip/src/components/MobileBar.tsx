import { CONTACT, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { waBookingLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'

/** Barra de acciones fija abajo en celular: siempre a un toque de reservar. */
export function MobileBar({ onMenu }: { onMenu: () => void }) {
  const { t, lang } = useLang()
  const { openBooking } = useBooking()
  const wa = waBookingLink(lang)
  return (
    <nav className="mobile-bar" aria-label={t(T.booking.open)}>
      <button type="button" className="mb-primary" onClick={() => openBooking()}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden><rect x="4" y="5" width="16" height="15" rx="2" /><path d="M8 3v4M16 3v4M4 10h16" /></svg>
        {t(T.bar.reserve)}
      </button>
      {wa && <a href={wa} target="_blank" rel="noopener noreferrer"><WhatsAppIcon size={18} />WhatsApp</a>}
      <button type="button" onClick={onMenu}>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden><path d="M5 6h14M5 12h14M5 18h9" /></svg>
        {t(T.bar.menu)}
      </button>
      <a href={CONTACT.directionsUrl} target="_blank" rel="noopener noreferrer">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden><path d="M12 21s-6-5.6-6-11a6 6 0 0 1 12 0c0 5.4-6 11-6 11z" /><circle cx="12" cy="10" r="2.2" /></svg>
        {t(T.bar.route)}
      </a>
    </nav>
  )
}
