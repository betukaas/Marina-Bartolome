import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'motion/react'
import { useState } from 'react'
import { T } from '../data/site'
import { useLang } from '../lib/i18n'
import { EASE_OUT } from '../lib/motion'
import { waBookingLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'

/** Botón flotante de WhatsApp: aparece al dejar la portada y se oculta en la sección de reservas. */
export function FloatingWhatsApp() {
  const { t, lang } = useLang()
  const { scrollY } = useScroll()
  const [show, setShow] = useState(false)
  useMotionValueEvent(scrollY, 'change', (y) => {
    const res = document.getElementById('visita')?.getBoundingClientRect()
    const inBooking = !!res && res.top < innerHeight * 0.6 && res.bottom > innerHeight * 0.4
    setShow(y > innerHeight * 0.8 && !inBooking)
  })
  const href = waBookingLink(lang)
  if (!href) return null
  return (
    <AnimatePresence>
      {show && (
        <motion.a
          className="fab-wa"
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={`WhatsApp · ${t(T.visit.fab)}`}
          initial={{ y: 90, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 90, opacity: 0 }}
          transition={{ duration: 0.6, ease: EASE_OUT }}
        >
          <WhatsAppIcon size={22} />
          <span>{t(T.visit.fab)}</span>
        </motion.a>
      )}
    </AnimatePresence>
  )
}
