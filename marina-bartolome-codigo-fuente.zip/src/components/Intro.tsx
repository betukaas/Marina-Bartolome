import { AnimatePresence, motion, useReducedMotion } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { IMG, T } from '../data/site'
import { useLang } from '../lib/i18n'
import { EASE_IN_OUT, EASE_OUT } from '../lib/motion'
import { src } from './Picture'

const BASE = import.meta.env.BASE_URL
const LETTERS = 'BARTOLOMÉ'.split('')
/** Si el video no arranca (conexión lenta o reproducción bloqueada), la intro no retiene al visitante */
const MAX_WAIT_MS = 6000

/**
 * Entrada: video del logotipo animado (el capitán gira el timón y la cámara entra en él).
 * Al terminar se desvanece hacia la portada. Una vez por sesión; se puede saltar tocando la pantalla.
 * Con movimiento reducido se muestra el logo fijo un instante.
 */
export function Intro({ onDone }: { onDone: () => void }) {
  const { t } = useLang()
  const reduce = useReducedMotion()
  const [show, setShow] = useState(() => {
    try { return sessionStorage.getItem('mb-intro') !== '1' } catch { return true }
  })
  const video = useRef<HTMLVideoElement>(null)
  const timer = useRef<number>(0)

  useEffect(() => {
    if (!show) { onDone(); return }
    const pre = new Image(); pre.src = src(innerWidth >= innerHeight ? IMG.portadaPanorama : IMG.portada)
    timer.current = window.setTimeout(finish, reduce ? 900 : MAX_WAIT_MS)
    if (!reduce) video.current?.play().catch(finish)
    return () => clearTimeout(timer.current)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function finish() {
    clearTimeout(timer.current)
    try { sessionStorage.setItem('mb-intro', '1') } catch { /* sin almacenamiento */ }
    setShow(false)
  }

  return (
    <AnimatePresence onExitComplete={onDone}>
      {show && (
        <motion.div
          className="intro"
          role="presentation"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          onClick={finish}
        >
          <div className="intro-stage">
          {reduce ? (
            <img className="intro-video" src={`${BASE}images/intro-poster.webp`} width={800} height={786} alt="Restaurant-Bar-Marina Bartolomé" />
          ) : (
            <video
              ref={video}
              className="intro-video"
              poster={`${BASE}images/intro-poster.webp`}
              width={800}
              height={786}
              muted
              playsInline
              preload="auto"
              onEnded={finish}
              aria-label="Restaurant-Bar-Marina Bartolomé"
            >
              {/* MP4 para Safari/Chrome/Edge; WebM de respaldo. Si ninguno se puede reproducir, pasa a la portada */}
              <source src={`${BASE}video/intro-capitan.mp4`} type="video/mp4" />
              <source src={`${BASE}video/intro-capitan.webm`} type="video/webm" onError={finish} />
            </video>
          )}
            <div className="intro-word" aria-label="Marina Bartolomé">
              <motion.span className="intro-kicker" initial={{ opacity: 0, letterSpacing: '1.1em' }} animate={{ opacity: 1, letterSpacing: '0.6em' }} transition={{ duration: 1.3, delay: 0.2, ease: EASE_OUT }}>
                MARINA
              </motion.span>
              <span className="intro-name">
                {LETTERS.map((l, i) => (
                  <span className="mask-line" key={i}>
                    <motion.span className="mask-inner" initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ duration: 1, delay: 0.4 + i * 0.05, ease: EASE_OUT }}>
                      {l}
                    </motion.span>
                  </span>
                ))}
              </span>
              <motion.i className="intro-line" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 1.2, delay: 0.9, ease: EASE_IN_OUT }} />
            </div>
          </div>
          <button className="intro-skip" onClick={finish} type="button">{t(T.skip)}</button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
