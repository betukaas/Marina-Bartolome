import { useState } from 'react'
import { CONTACT, HOURS, LOCALS_OFFER, PAYMENTS, SOCIAL, T } from '../data/site'
import { useLang } from '../lib/i18n'
import { waBookingLink } from '../lib/whatsapp'
import { FacebookIcon, InstagramIcon, TripadvisorIcon, WhatsAppIcon } from './Icons'
import { MaskText } from './MaskText'
import { Pending } from './Pending'
import { Reservation } from './Reservation'
import { Reveal } from './Reveal'

/** Estado en vivo según la hora de Isla Mujeres (America/Cancun) y el horario publicado. */
function OpenNow() {
  const { lang } = useLang()
  if (!HOURS) return null
  const hm = new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Cancun', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date())
  const [from, to] = HOURS[0].hours.split('–').map((x) => x.trim())
  const open = hm >= from && hm < to
  return <span className={`open-now ${open ? 'is-open' : ''}`}>{open ? (lang === 'es' ? 'Abierto ahora' : 'Open now') : (lang === 'es' ? 'Cerrado ahora' : 'Closed now')}</span>
}

function CopyButton({ text }: { text: string }) {
  const { t } = useLang()
  const [done, setDone] = useState(false)
  return (
    <button
      type="button"
      className="link-btn"
      onClick={() => navigator.clipboard?.writeText(text).then(() => { setDone(true); setTimeout(() => setDone(false), 1800) }, () => {})}
    >
      {done ? t(T.visit.copied) : t(T.visit.copy)}
    </button>
  )
}

export function Visit({ onPrivacy }: { onPrivacy: () => void }) {
  const { t, lang } = useLang()
  const v = T.visit
  const instagram = SOCIAL.find((s) => s.label === 'Instagram')
  const facebook = SOCIAL.find((s) => s.label === 'Facebook')
  const tripadvisor = SOCIAL.find((s) => s.label === 'Tripadvisor')
  const wa = waBookingLink(lang)

  return (
    <section className="visit surface-navy" id="visita">
      <div className="wrap">
        <header className="section-head">
          <p className="eyebrow">{t(v.eyebrow)}</p>
          <MaskText className="display display-pearl" lines={[t(v.title1), <em key="e">{t(v.title2)}</em>]} />
        </header>

        <div className="visit-grid">
          <div className="visit-info">
            <Reveal className="info-block">
              <h3>{t(v.contact)}</h3>
              {CONTACT.whatsapp && wa && (
                <a className="contact-row" href={wa} target="_blank" rel="noopener noreferrer">
                  <span className="contact-icon"><WhatsAppIcon /></span>
                  <span><small>{t(v.whatsapp)}</small><b className="selectable">{CONTACT.whatsappDisplay}</b></span>
                </a>
              )}
              {instagram?.url && (
                <a className="contact-row" href={instagram.url} target="_blank" rel="noopener noreferrer">
                  <span className="contact-icon"><InstagramIcon /></span>
                  <span><small>Instagram</small><b>{instagram.handle}</b></span>
                </a>
              )}
              {facebook?.url && (
                <a className="contact-row" href={facebook.url} target="_blank" rel="noopener noreferrer">
                  <span className="contact-icon"><FacebookIcon /></span>
                  <span><small>Facebook</small><b>{facebook.handle}</b></span>
                </a>
              )}
              {tripadvisor?.url && (
                <a className="contact-row" href={tripadvisor.url} target="_blank" rel="noopener noreferrer">
                  <span className="contact-icon contact-icon-ta"><TripadvisorIcon /></span>
                  <span><small>Tripadvisor</small><b>{tripadvisor.handle}</b></span>
                </a>
              )}
              {CONTACT.phone && (
                <div className="info-actions">
                  <span className="muted info-small">{t(v.phone)}: <span className="selectable">{CONTACT.phone}</span></span>
                  <a className="arrow-link" href={`tel:${CONTACT.phoneIntl}`}>{t(v.call)}</a>
                  <CopyButton text={CONTACT.phone} />
                </div>
              )}
            </Reveal>
            <Reveal className="info-block" delay={0.08}>
              <h3>{t(v.location)}</h3>
              <p>{CONTACT.address}</p>
              <p className="muted info-small">{CONTACT.locality}</p>
              <a className="arrow-link" href={CONTACT.directionsUrl} target="_blank" rel="noopener noreferrer">{t(v.maps)} <span aria-hidden>↗</span></a>
            </Reveal>
            <Reveal className="info-block" delay={0.16}>
              <h3>{t(v.hours)} <OpenNow /></h3>
              {HOURS ? (
                <dl className="hours">{HOURS.map((h, i) => <div key={i}><dt>{t(h.days)}</dt><dd>{h.hours}</dd></div>)}</dl>
              ) : <p><Pending /></p>}
            </Reveal>
            <Reveal className="info-block" delay={0.24}>
              <h3>{t(T.extras.payments)}</h3>
              <p className="info-small">{t(PAYMENTS.currencies)}</p>
              <ul className="pay-chips">{PAYMENTS.cards.map((c) => <li key={c}>{c}</li>)}</ul>
            </Reveal>
            <Reveal className="info-block locals" delay={0.3}>
              <p className="locals-badge">{t(T.extras.locals).replace('{p}', String(LOCALS_OFFER.percent))}</p>
              <p className="muted info-small">{t(T.extras.localsNote)}</p>
            </Reveal>
          </div>
          {CONTACT.takesReservations && (
            <Reveal delay={0.1}>
              <div id="reservar"><Reservation onPrivacy={onPrivacy} /></div>
            </Reveal>
          )}
        </div>
      </div>
    </section>
  )
}
