import { motion } from 'motion/react'
import type { ReactNode } from 'react'
import { DUR, EASE_OUT, viewportOnce } from '../lib/motion'

/** Entrada suave (opacidad + desplazamiento) al aparecer en pantalla. */
export function Reveal({ children, delay = 0, y = 32, className }: { children: ReactNode; delay?: number; y?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches ? Math.min(y, 14) : y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={viewportOnce}
      transition={{ duration: DUR.base, ease: EASE_OUT, delay }}
    >
      {children}
    </motion.div>
  )
}

/** Fotografía que se descubre con una cortina y un ligero zoom de salida. */
export function ImageReveal({ children, className, delay = 0, from = 'bottom' }: { children: ReactNode; className?: string; delay?: number; from?: 'bottom' | 'left' | 'right' }) {
  const hidden = { bottom: 'inset(100% 0% 0% 0%)', left: 'inset(0% 100% 0% 0%)', right: 'inset(0% 0% 0% 100%)' }[from]
  return (
    <motion.div
      className={`img-reveal ${className ?? ''}`}
      initial={{ clipPath: hidden }}
      whileInView={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      viewport={viewportOnce}
      transition={{ duration: DUR.slow, ease: [0.76, 0, 0.24, 1], delay }}
    >
      <motion.div
        className="img-reveal-inner"
        initial={{ scale: 1.25 }}
        whileInView={{ scale: 1 }}
        viewport={viewportOnce}
        transition={{ duration: 2.2, ease: EASE_OUT, delay }}
      >
        {children}
      </motion.div>
    </motion.div>
  )
}
