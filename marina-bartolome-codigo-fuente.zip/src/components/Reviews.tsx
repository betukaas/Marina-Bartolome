import { useReducedMotion } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { CONTACT, IMG, REVIEWS, SOCIAL, T, type Review } from '../data/site'
import { useLang } from '../lib/i18n'
import { GoogleG, GoogleWord, TripadvisorIcon } from './Icons'
import { MaskText } from './MaskText'
import { Picture } from './Picture'
import { Reveal } from './Reveal'

/** El iframe de Google Maps no funciona en la vista previa de Artifact; ahí se muestra una tarjeta. */
const SHOW_MAP = import.meta.env.VITE_ARTIFACT !== '1'
const LONG = 260
/** Tiempo que se queda cada reseña antes de pasar a la siguiente */
const HOLD_MS = 1500

function Stars({ n }: { n: number }) {
  return <span className="stars" aria-label={`${n} / 5`}>{'★★★★★'.slice(0, n)}<i>{'★★★★★'.slice(n)}</i></span>
}

/** Reseña textual de Google; las largas se recortan con "Leer completa" */
function ReviewCard({ rv, onToggle, hidden }: { rv: Review; onToggle?: (open: boolean) => void; hidden?: boolean }) {
  const { t, lang } = useLang()
  const r = T.reviews
  const [open, setOpen] = useState(false)
  const text = t(rv.text)
  const long = text.length > LONG
  const shown = long && !open ? text.slice(0, text.lastIndexOf(' ', LONG)) + '…' : text
  return (
    <figure className="review-card" lang={rv.lang} aria-hidden={hidden || undefined}>
      <div className="review-top">
        <Stars n={rv.rating} />
        <span className="review-g" aria-label="Google">G</span>
      </div>
      <blockquote>“{shown}”</blockquote>
      {long && <button type="button" tabIndex={hidden ? -1 : undefined} className="link-btn review-more" onClick={() => { setOpen(!open); onToggle?.(!open) }}>{t(open ? r.less : r.more)}</button>}
      <figcaption className="review-meta">
        <span className="review-avatar" aria-hidden>{rv.author[0]}</span>
        <span>
          <b>{rv.author}</b>
          <small>{[rv.badge, t(r.source)].filter(Boolean).join(' · ')}{rv.lang !== lang && ` · ${t(r.original)}`}</small>
          {rv.scores && <small className="review-scores">{t(r.scores)}</small>}
        </span>
      </figcaption>
    </figure>
  )
}

const TRIPADVISOR = SOCIAL.find((s) => s.label === 'Tripadvisor')?.url

/** Reseñas reales de Google y ubicación con mapa (satélite o calles). */
export function Reviews() {
  const { t } = useLang()
  const r = T.reviews
  const [view, setView] = useState<'map' | 'isla' | 'sat'>('map')
  const reduce = useReducedMotion()
  const [paused, setPaused] = useState(false)
  const [expanded, setExpanded] = useState(0)
  const still = reduce || paused || expanded > 0
  const onToggle = (open: boolean) => setExpanded((n) => n + (open ? 1 : -1))
  const [hover, setHover] = useState(false)
  // Avanza de una en una hacia la derecha. La pista lleva tres copias; al salir de la copia central
  // salta sin animación a la posición idéntica, así el ciclo nunca termina en ninguna dirección.
  const n = REVIEWS.length
  const [idx, setIdx] = useState(n)
  const [animate, setAnimate] = useState(true)
  const [step, setStep] = useState(0)
  const [drag, setDrag] = useState<{ x0: number; y0: number; dx: number; id: number; lock: boolean } | null>(null)
  const [heldUntil, setHeldUntil] = useState(0)
  const trackRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const measure = () => {
      const cards = trackRef.current?.querySelectorAll('.review-card')
      if (cards && cards.length > 1) setStep((cards[1] as HTMLElement).offsetLeft - (cards[0] as HTMLElement).offsetLeft)
    }
    measure()
    addEventListener('resize', measure)
    return () => removeEventListener('resize', measure)
  }, [])
  const go = (d: number) => { setAnimate(true); setIdx((i) => i + d) }
  // Tras usar flechas o deslizar, el carrusel espera unos segundos antes de seguir solo
  const hold = () => setHeldUntil(Date.now() + 5000)
  useEffect(() => {
    if (still || hover || drag) return
    const wait = Math.max(HOLD_MS, heldUntil - Date.now())
    const id = setTimeout(() => go(-1), wait)
    return () => clearTimeout(id)
  }, [idx, still, hover, drag, heldUntil])
  const onSlideEnd = () => {
    if (idx < n) { setAnimate(false); setIdx(idx + n) }
    else if (idx >= 2 * n) { setAnimate(false); setIdx(idx - n) }
  }
  const onDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button')) return
    setDrag({ x0: e.clientX, y0: e.clientY, dx: 0, id: e.pointerId, lock: false })
    setAnimate(false)
  }
  const onMove = (e: React.PointerEvent) => {
    if (!drag || e.pointerId !== drag.id) return
    const dx = e.clientX - drag.x0
    const dy = e.clientY - drag.y0
    // Solo arrastra si el gesto es claramente horizontal; si es vertical, deja que la página se desplace
    if (!drag.lock) {
      if (Math.abs(dx) < 10 && Math.abs(dy) < 10) return
      if (Math.abs(dy) >= Math.abs(dx)) { setDrag(null); setAnimate(true); return }
      ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
    }
    setDrag({ ...drag, dx, lock: true })
  }
  const onUp = () => {
    if (!drag) return
    const moved = Math.abs(drag.dx) > Math.min(70, step / 4) ? Math.max(1, Math.round(Math.abs(drag.dx) / (step || 1))) * -Math.sign(drag.dx) : 0
    setDrag(null)
    setAnimate(true)
    setIdx((i) => i + moved)
    hold()
  }
  const offset = -idx * step + (drag?.dx ?? 0)

  return (
    <section className="reviews surface-pearl" id="resenas">
      <div className="wrap">
        <header className="section-head">
          <p className="eyebrow eyebrow-dark">{t(r.eyebrow)}</p>
          <MaskText className="display" lines={[t(r.title1), <em key="e">{t(r.title2)}</em>]} />
        </header>

        {REVIEWS.length > 0 && (
          <div className="review-marquee-wrap">
            {/* Cada reseña se queda 1.5 s y pasa a la siguiente. Se puede pausar, usar las flechas o deslizar con el dedo / arrastrar con el mouse */}
            <div
              className={`review-marquee ${reduce ? 'is-static' : ''} ${drag ? 'is-dragging' : ''}`}
              onMouseEnter={() => setHover(true)}
              onMouseLeave={() => { setHover(false); onUp() }}
              onFocus={() => setHover(true)}
              onBlur={() => setHover(false)}
              onPointerDown={reduce ? undefined : onDown}
              onPointerMove={reduce ? undefined : onMove}
              onPointerUp={reduce ? undefined : onUp}
              onPointerCancel={reduce ? undefined : onUp}
              data-cursor={reduce ? undefined : '⟷'}
            >
              <div
                className="review-track"
                ref={trackRef}
                onTransitionEnd={onSlideEnd}
                style={reduce ? undefined : { transform: `translateX(${offset}px)`, transition: animate ? 'transform 0.8s cubic-bezier(0.76, 0, 0.24, 1)' : 'none' }}
              >
                {[0, 1, 2].map((copy) =>
                  REVIEWS.map((rv) => <ReviewCard key={`${copy}-${rv.author}`} rv={rv} hidden={copy !== 1} onToggle={copy === 1 ? onToggle : undefined} />),
                )}
              </div>
            </div>
            {!reduce && (
              <div className="review-controls">
                <button type="button" className="review-arrow" onClick={() => { go(1); hold() }} aria-label={t(r.prev)}>←</button>
                <button type="button" className="review-pause" onClick={() => setPaused(!paused)} aria-pressed={paused}>
                  {paused ? `▶ ${t(r.play)}` : `❚❚ ${t(r.pause)}`}
                </button>
                <button type="button" className="review-arrow" onClick={() => { go(-1); hold() }} aria-label={t(r.next)}>→</button>
              </div>
            )}
          </div>
        )}

        <div className="reviews-grid">
          <Reveal className="reviews-cta">
            <span className="reviews-quote" aria-hidden>“</span>
            <p>{t(r.empty)}</p>
            <div className="reviews-actions">
              <a className="btn btn-navy" href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer"><span>{t(r.write)}</span></a>
              <a className="btn btn-outline-navy btn-brand" href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer"><span><GoogleG />{t(r.read)} <GoogleWord /></span></a>
              {TRIPADVISOR && (
                <a className="btn btn-tripadvisor btn-brand" href={TRIPADVISOR} target="_blank" rel="noopener noreferrer"><span><i className="ta-owl"><TripadvisorIcon size={18} /></i>{t(r.tripadvisor)} <b className="brand-ta">Tripadvisor</b></span></a>
              )}
            </div>
          </Reveal>
          <Reveal delay={0.12} className="reviews-map">
            <div className="map-frame">
              {SHOW_MAP ? (
                <iframe
                  key={view}
                  title={t(r.find)}
                  src={{ map: CONTACT.mapsEmbed, isla: CONTACT.mapsEmbedIsla, sat: CONTACT.mapsEmbedSat }[view]}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                />
              ) : (
                <a className="map-card" href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer" data-cursor="Maps">
                  <Picture img={IMG.fachadaPanorama} sizes="(min-width: 960px) 50vw, 92vw" decorative />
                  <span className="map-pin" aria-hidden />
                </a>
              )}
              {SHOW_MAP && (
                <div className="map-toggle" role="group" aria-label={t(r.find)}>
                  <button type="button" aria-pressed={view === 'map'} onClick={() => setView('map')}>{t(r.viewMap)}</button>
                  <button type="button" aria-pressed={view === 'isla'} onClick={() => setView('isla')}>{t(r.viewIsla)}</button>
                  <button type="button" aria-pressed={view === 'sat'} onClick={() => setView('sat')}>{t(r.viewSat)}</button>
                </div>
              )}
            </div>
            <div className="reviews-map-foot">
              <p>{t(r.find)}<br /><span>{CONTACT.address}, {CONTACT.locality}</span></p>
              <div className="map-links">
                <a className="btn btn-navy btn-sm" href={CONTACT.directionsUrl} target="_blank" rel="noopener noreferrer"><span>{t(r.directions)}</span></a>
                <a className="arrow-link arrow-link-dark" href={CONTACT.mapsUrl} target="_blank" rel="noopener noreferrer">{t(r.open)} <span aria-hidden>↗</span></a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
