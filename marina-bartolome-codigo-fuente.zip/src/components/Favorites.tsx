import { motion } from 'motion/react'
import { useRef } from 'react'
import { FAVORITES, MENU, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { EASE_OUT } from '../lib/motion'
import { MaskText } from './MaskText'
import { Picture } from './Picture'

/**
 * Favoritos de la casa justo después de la portada: platillos estrella con foto grande,
 * descripción y precio. La acción invita a reservar mesa para probarlo en el restaurante.
 */
export function Favorites({ onMenu }: { onMenu: (id?: string) => void }) {
  const { t } = useLang()
  const { openBooking } = useBooking()
  const f = T.favorites
  const track = useRef<HTMLDivElement>(null)
  const step = (dir: number) => {
    const el = track.current; if (!el) return
    const card = el.querySelector('article') as HTMLElement | null
    el.scrollBy({ left: dir * ((card?.offsetWidth ?? 380) + 40), behavior: 'smooth' })
  }

  return (
    <section className="favorites surface-pearl" id="cocina" aria-labelledby="fav-title">
      <div className="wrap">
        <div className="fav-head">
          <div>
            <p className="eyebrow eyebrow-dark" id="fav-title">{t(f.eyebrow)}</p>
            <MaskText className="display fav-title" lines={[t(f.title1), <em key="e">{t(f.title2)}</em>]} />
            <p className="lead fav-lead">{t(f.lead)}</p>
            <nav className="fav-cats" aria-label={t(f.browse)}>
              {MENU.map((sec) => (
                <button key={sec.id} type="button" onClick={() => onMenu(sec.id)}>{t(sec.title)}</button>
              ))}
            </nav>
          </div>
          <div className="fav-nav">
            <button type="button" onClick={() => step(-1)} aria-label="←">←</button>
            <button type="button" onClick={() => step(1)} aria-label="→">→</button>
          </div>
        </div>
      </div>
      <div className="fav-track" ref={track}>
        {FAVORITES.map((fav, i) => (
          <motion.article
            key={i}
            className="fav-card"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '0px -5% -10% 0px' }}
            transition={{ duration: 0.9, ease: EASE_OUT, delay: i * 0.06 }}
          >
            <button type="button" className="fav-img" onClick={() => onMenu(fav.menuId)} data-cursor={t(T.nav.menu)} aria-label={`${t(fav.item.name)} — ${t(f.inMenu)}`}>
              <Picture img={fav.img} sizes="(min-width: 960px) 30vw, 82vw" />
              {fav.item.star && <span className="fav-star">★ {t(T.menu.star)}</span>}
            </button>
            <div className="fav-body">
              <div className="fav-row">
                <h3>{t(fav.item.name)}</h3>
                <span className="fav-price">{fav.item.price}</span>
              </div>
              {fav.item.desc && <p className="fav-desc">{t(fav.item.desc)}</p>}
              {fav.item.note && <p className="fav-note">{t(fav.item.note)}</p>}
              <div className="fav-actions">
                <button type="button" className="link-btn fav-cta" onClick={() => openBooking({ notes: `${t(f.note)}: ${t(fav.item.name)}` })}>
                  {t(f.want)} <span aria-hidden>→</span>
                </button>
                <button type="button" className="link-btn fav-link" onClick={() => onMenu(fav.menuId)}>{t(f.inMenu)}</button>
              </div>
            </div>
          </motion.article>
        ))}
        <article className="fav-card fav-more">
          <button type="button" onClick={() => onMenu()}>
            <span>{t(f.all)}</span>
            <i aria-hidden>→</i>
          </button>
        </article>
      </div>
    </section>
  )
}
