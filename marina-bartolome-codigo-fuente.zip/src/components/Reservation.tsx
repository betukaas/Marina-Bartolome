import { useMemo, useState, type MouseEvent } from 'react'
import { BOOKING_HOURS, CONTACT, T } from '../data/site'
import type { BookingPrefill } from '../lib/booking'
import { suggestedArrival, sunsetFor } from '../lib/sun'
import { useLang } from '../lib/i18n'
import { bookingMessage, waLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

/**
 * Reserva por WhatsApp: el formulario arma el mensaje en vivo (fecha, hora, personas,
 * ocasión, alergias y comentarios) y el botón abre la conversación del restaurante
 * con todo escrito. Si falta un dato obligatorio, el botón no navega y señala el error.
 */
export function Reservation({ onPrivacy, prefill = {}, idPrefix = 'r' }: { onPrivacy: () => void; prefill?: BookingPrefill; idPrefix?: string }) {
  const { t, lang } = useLang()
  const v = T.visit
  const today = new Date()
  const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1)
  const [f, setF] = useState({ name: '', guests: prefill.guests ?? '2', date: prefill.date ?? iso(tomorrow), time: prefill.time ?? '14:00', occasion: 0, allergies: '', notes: prefill.notes ?? '', bySea: false, boatType: 0, boatName: '', boatLength: '', dock: true })
  const [error, setError] = useState('')
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => { setF({ ...f, [k]: k === 'occasion' || k === 'boatType' ? Number(e.target.value) : e.target.value }); setError('') }

  const message = useMemo(() => {
    const [y, mo, d] = f.date.split('-').map(Number)
    const day = f.date ? new Date(y, mo - 1, d).toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' }) : ''
    return bookingMessage(lang, {
      name: f.name,
      guests: f.guests,
      date: day,
      time: f.time,
      occasion: f.occasion > 0 ? t(v.occasions[f.occasion]) : lang === 'es' ? 'Ninguna' : 'None',
      allergies: f.allergies.trim() || (lang === 'es' ? 'Ninguna' : 'None'),
      notes: f.notes.trim() || '—',
      boat: f.bySea
        ? [
            t(v.boatTypes[f.boatType]) + (f.boatName.trim() ? ` "${f.boatName.trim()}"` : ''),
            f.boatLength.trim() ? `${f.boatLength.trim()} ft` : '',
            `${lang === 'es' ? 'Amarre' : 'Docking'}: ${t(f.dock ? v.yes : v.no)}`,
          ].filter(Boolean).join(' · ')
        : t(v.no),
    })
  }, [f, lang, t, v.occasions, v.boatTypes, v.yes, v.no])

  /** Pone la hora sugerida para ver el atardecer en la fecha elegida */
  function applySunset() {
    const [y, mo, d] = (f.date || iso(tomorrow)).split('-').map(Number)
    const time = suggestedArrival(sunsetFor(y, mo, d), BOOKING_HOURS.first, BOOKING_HOURS.last)
    const comment = t(T.sunset.comment)
    setF({ ...f, time, notes: f.notes.includes(comment) ? f.notes : [comment, f.notes].filter(Boolean).join('. ') })
    setError('')
  }

  function validate(e: MouseEvent) {
    let err = ''
    if (!f.name.trim()) err = t(v.errName)
    else if (!f.date || f.date < iso(today)) err = t(v.errDate)
    else if (!f.time || f.time < BOOKING_HOURS.first || f.time > BOOKING_HOURS.last) err = t(v.errTime)
    if (err) {
      e.preventDefault()
      setError(err)
    }
  }

  const href = waLink(message)

  return (
    <div className="reserve">
      <h3 className="reserve-title">{t(v.reserveTitle)}</h3>
      <p className="reserve-lead">{t(v.reserveLead)}</p>
      <form className="reserve-form" onSubmit={(e) => e.preventDefault()} noValidate>
        <div className="field field-full">
          <label htmlFor={`${idPrefix}-name`}>{t(v.name)}</label>
          <input id={`${idPrefix}-name`} autoComplete="name" value={f.name} onChange={set('name')} required aria-invalid={error === t(v.errName)} />
        </div>
        <div className="field">
          <label htmlFor={`${idPrefix}-guests`}>{t(v.guests)}</label>
          <select id={`${idPrefix}-guests`} value={f.guests} onChange={set('guests')}>
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13+'].map((n) => <option key={n}>{n}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor={`${idPrefix}-date`}>{t(v.date)}</label>
          <input id={`${idPrefix}-date`} type="date" min={iso(today)} value={f.date} onChange={set('date')} required />
        </div>
        <div className="field">
          <label htmlFor={`${idPrefix}-time`}>{t(v.time)}</label>
          <input id={`${idPrefix}-time`} type="time" step={900} min={BOOKING_HOURS.first} max={BOOKING_HOURS.last} value={f.time} onChange={set('time')} />
        </div>
        <button type="button" className="link-btn sunset-fill" onClick={applySunset}>☀ {t(T.sunset.useTime)}</button>
        <div className="field field-full">
          <label htmlFor={`${idPrefix}-occasion`}>{t(v.occasion)}</label>
          <select id={`${idPrefix}-occasion`} value={f.occasion} onChange={set('occasion')}>
            {v.occasions.map((o, i) => <option key={i} value={i}>{t(o)}</option>)}
          </select>
        </div>
        <div className="field field-full">
          <label htmlFor={`${idPrefix}-allergies`}>{t(v.allergies)}</label>
          <input id={`${idPrefix}-allergies`} value={f.allergies} onChange={set('allergies')} placeholder={t(v.allergiesPh)} />
        </div>
        <div className="field field-full sea">
          <label className="sea-toggle" htmlFor={`${idPrefix}-sea`}>
            <input id={`${idPrefix}-sea`} type="checkbox" checked={f.bySea} onChange={(e) => setF({ ...f, bySea: e.target.checked })} />
            <span className="sea-switch" aria-hidden />
            <span><b>⛵ {t(v.bySea)}</b><small>{t(v.bySeaHint)}</small></span>
          </label>
          {f.bySea && (
            <div className="sea-fields">
              <div className="field">
                <label htmlFor={`${idPrefix}-boat-type`}>{t(v.boatType)}</label>
                <select id={`${idPrefix}-boat-type`} value={f.boatType} onChange={set('boatType')}>
                  {v.boatTypes.map((o, i) => <option key={i} value={i}>{t(o)}</option>)}
                </select>
              </div>
              <div className="field">
                <label htmlFor={`${idPrefix}-boat-name`}>{t(v.boatName)}</label>
                <input id={`${idPrefix}-boat-name`} value={f.boatName} onChange={set('boatName')} placeholder={t(v.boatNamePh)} />
              </div>
              <div className="field">
                <label htmlFor={`${idPrefix}-boat-length`}>{t(v.boatLength)}</label>
                <input id={`${idPrefix}-boat-length`} type="number" inputMode="numeric" min={10} max={200} value={f.boatLength} onChange={set('boatLength')} placeholder="40" />
              </div>
              <div className="field">
                <span className="sea-label">{t(v.boatDock)}</span>
                <div className="sea-choice" role="radiogroup" aria-label={t(v.boatDock)}>
                  {[true, false].map((val) => (
                    <button key={String(val)} type="button" role="radio" aria-checked={f.dock === val} onClick={() => setF({ ...f, dock: val })}>{t(val ? v.yes : v.no)}</button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="field field-full">
          <label htmlFor={`${idPrefix}-notes`}>{t(v.notes)}</label>
          <textarea id={`${idPrefix}-notes`} rows={2} placeholder={t(v.notesPh)} value={f.notes} onChange={set('notes')} />
        </div>

        <details className="reserve-preview">
          <summary>{t(v.preview)}</summary>
          <pre>{message}</pre>
        </details>

        <p className="form-error" role="alert">{error}</p>
        {href && (
          <div className="reserve-submit">
            <a className="btn btn-wa" href={href} target="_blank" rel="noopener noreferrer" onClick={validate}>
              <WhatsAppIcon size={20} /><span>{t(v.openWa)}</span>
            </a>
            <p className="muted reserve-hint">{t(v.waHint)} · {CONTACT.whatsappDisplay}</p>
            <p className="muted reserve-hint">{t(T.privacy.consent)} <button type="button" className="inline-link" onClick={onPrivacy}>{t(T.privacy.link).toLowerCase()}</button>.</p>
          </div>
        )}
      </form>
    </div>
  )
}
