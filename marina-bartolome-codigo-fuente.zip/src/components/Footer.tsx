import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { useRef } from 'react'
import { BRAND, CONTACT, HOURS, SOCIAL, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { FacebookIcon, InstagramIcon, TripadvisorIcon, WhatsAppIcon } from './Icons'
import { Pending } from './Pending'
import { waBookingLink } from '../lib/whatsapp'

const BASE = import.meta.env.BASE_URL

/** Cierre: el timón gira con el scroll y el nombre ocupa todo el ancho sobre una línea de agua. */
export function Footer({ onPrivacy }: { onPrivacy: () => void }) {
  const { t, lang } = useLang()
  const { openBooking } = useBooking()
  const reduce = useReducedMotion()
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end end'] })
  const rotate = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [-120, 0])
  const y = useTransform(scrollYProgress, [0, 1], reduce ? ['0%', '0%'] : ['40%', '0%'])
  const hasSocial = SOCIAL.some((s) => s.url)

  return (
    <footer className="footer" ref={ref}>
      <svg className="footer-waves" viewBox="0 0 1440 80" preserveAspectRatio="none" aria-hidden>
        <path d="M0 40 Q 180 10 360 40 T 720 40 T 1080 40 T 1440 40" />
        <path d="M0 56 Q 180 26 360 56 T 720 56 T 1080 56 T 1440 56" />
      </svg>
      <div className="wrap">
        <div className="footer-top">
          <motion.img src={`${BASE}images/logo-perla-512.webp`} width={150} height={150} alt="Logotipo Restaurant-Bar-Marina Bartolomé" style={{ rotate }} loading="lazy" />
          <div className="footer-cols">
            <div>
              <h4>{t(BRAND.descriptor)}</h4>
              <p>{CONTACT.address}<br />{CONTACT.locality}</p>
              {HOURS && <p>{t(HOURS[0].days)} · {HOURS[0].hours}</p>}
            </div>
            <nav aria-label="Pie de página">
              <a href="#cocina">{t(T.nav.cuisine)}</a>
              <a href="#experiencia">{t(T.nav.experience)}</a>
              <a href="#eventos">{t(T.nav.events)}</a>
              <a href="#visita">{t(T.nav.visit)}</a>
              <button type="button" className="footer-nav-btn" onClick={() => openBooking()}>{t(T.nav.reserve)}</button>
            </nav>
            <div>
              <h4>{t(T.footer.follow)}</h4>
              <div className="footer-icons">
                {SOCIAL.find((s) => s.label === 'Instagram')?.url && (
                  <a href={SOCIAL.find((s) => s.label === 'Instagram')!.url!} target="_blank" rel="noopener noreferrer" aria-label="Instagram"><InstagramIcon size={22} /></a>
                )}
                {SOCIAL.find((s) => s.label === 'Facebook')?.url && (
                  <a href={SOCIAL.find((s) => s.label === 'Facebook')!.url!} target="_blank" rel="noopener noreferrer" aria-label="Facebook"><FacebookIcon size={22} /></a>
                )}
                {SOCIAL.find((s) => s.label === 'Tripadvisor')?.url && (
                  <a href={SOCIAL.find((s) => s.label === 'Tripadvisor')!.url!} target="_blank" rel="noopener noreferrer" aria-label="Tripadvisor"><TripadvisorIcon size={24} /></a>
                )}
                {waBookingLink(lang) && (
                  <a href={waBookingLink(lang)!} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"><WhatsAppIcon size={22} /></a>
                )}
              </div>
              {hasSocial
                ? SOCIAL.filter((s) => s.url).map((s) => <a key={s.label} href={s.url!} target="_blank" rel="noopener noreferrer">{s.label === 'Instagram' ? s.handle : s.label} ↗</a>)
                : <p><Pending /></p>}
              {CONTACT.whatsapp && <p>WhatsApp {CONTACT.whatsappDisplay}</p>}
              {CONTACT.phone && <p>Tel. {CONTACT.phone}</p>}
            </div>
          </div>
        </div>
        <div className="footer-word" aria-hidden>
          <motion.span style={{ y }}>Bartolomé</motion.span>
        </div>
        <div className="footer-legal">
          <span>© {new Date().getFullYear()} {BRAND.name}. {t(T.footer.rights)}</span>
          <span className="footer-legal-links">
            <button type="button" className="inline-link" onClick={onPrivacy}>{t(T.privacy.link)}</button>
            <a href="#inicio">{t(T.footer.top)} ↑</a>
          </span>
        </div>
      </div>
    </footer>
  )
}
