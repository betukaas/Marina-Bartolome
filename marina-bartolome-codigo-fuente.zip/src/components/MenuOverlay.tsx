import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { CONTACT, MENU, PAYMENTS, PRICES_CONFIRMED, T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { EASE_IN_OUT, EASE_OUT } from '../lib/motion'
import { Pending } from './Pending'
import { Picture } from './Picture'

/** Carta a pantalla completa con pestañas por sección. Cierra con Esc o con el botón. */
export function MenuOverlay({ open, initial, onClose }: { open: boolean; initial?: string; onClose: () => void }) {
  const { t } = useLang()
  const { openBooking } = useBooking()
  const [tab, setTab] = useState(MENU[0].id)
  const closeRef = useRef<HTMLButtonElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const lastFocus = useRef<Element | null>(null)

  useEffect(() => {
    if (!open) return
    if (initial) setTab(initial)
    lastFocus.current = document.activeElement
    document.body.style.overflow = 'hidden'
    const id = setTimeout(() => closeRef.current?.focus(), 400)
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', esc)
    return () => {
      clearTimeout(id)
      document.body.style.overflow = ''
      window.removeEventListener('keydown', esc)
      ;(lastFocus.current as HTMLElement | null)?.focus?.()
    }
  }, [open, initial, onClose])

  const section = MENU.find((c) => c.id === tab) ?? MENU[0]
  const choose = (id: string) => {
    setTab(id)
    bodyRef.current?.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={bodyRef}
          className="menu-overlay surface-pearl"
          role="dialog"
          aria-modal="true"
          aria-labelledby="menu-title"
          initial={{ clipPath: 'inset(100% 0% 0% 0%)' }}
          animate={{ clipPath: 'inset(0% 0% 0% 0%)' }}
          exit={{ clipPath: 'inset(0% 0% 100% 0%)' }}
          transition={{ duration: 0.9, ease: EASE_IN_OUT }}
        >
          <div className="menu-top">
            <div className="wrap menu-top-in">
              <h2 id="menu-title" className="menu-title">{t(T.menu.title)} {!PRICES_CONFIRMED && <Pending label={t(T.menu.pricesPending)} />}</h2>
              <button ref={closeRef} type="button" className="menu-close" onClick={onClose}>{t(T.nav.close)} <span aria-hidden>×</span></button>
            </div>
            <div className="wrap">
              <div className="menu-tabs" role="tablist" aria-label={t(T.menu.title)}>
                {MENU.map((c) => (
                  <button key={c.id} id={`tab-${c.id}`} role="tab" type="button" aria-selected={tab === c.id} aria-controls="menu-panel" onClick={() => choose(c.id)}>
                    {t(c.title)}
                    {tab === c.id && <motion.i layoutId="menu-tab-ink" className="menu-tab-ink" transition={{ duration: 0.5, ease: EASE_OUT }} />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="wrap menu-body">
            <AnimatePresence mode="wait">
              <motion.div key={section.id} id="menu-panel" role="tabpanel" aria-labelledby={`tab-${section.id}`} className="menu-panel" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.5, ease: EASE_OUT }}>
                <div className="menu-panel-media">
                  <Picture img={section.img} sizes="(min-width: 960px) 30vw, 92vw" />
                </div>
                <div className="menu-groups">
                  <p className="menu-intro">{t(section.intro)}</p>
                  {section.groups.map((g, gi) => (
                    <motion.section key={gi} className="menu-group" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + gi * 0.06, duration: 0.6, ease: EASE_OUT }}>
                      <header className="menu-group-head">
                        <h3>{t(g.title)}{g.local && <span className="menu-local" title={t(T.menu.local)}>{t(T.menu.local)}</span>}</h3>
                        {g.note && <p>{t(g.note)}</p>}
                      </header>
                      <ul className="menu-list">
                        {g.items.map((d, i) => (
                          <li key={i} className={d.desc ? '' : 'is-compact'}>
                            <div className="menu-dish-head">
                              <h4>
                                {d.star && <span className="menu-star" aria-label={t(T.menu.star)} title={t(T.menu.star)}>★</span>}
                                {t(d.name)}
                                {d.local && <span className="menu-local">{t(T.menu.local)}</span>}
                              </h4>
                              <span className="menu-dots" aria-hidden />
                              <span className="menu-price">{d.price}</span>
                            </div>
                            {d.desc && <p>{t(d.desc)}</p>}
                            {d.note && <p className="menu-note">{t(d.note)}</p>}
                          </li>
                        ))}
                      </ul>
                    </motion.section>
                  ))}
                  {section.id === 'bar' && <p className="menu-spirits">{t(T.menu.spirits)}</p>}
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="menu-foot">
              <p className="menu-legal"><span className="menu-star">★</span> {t(T.menu.star)} · <span className="menu-local">{t(T.menu.local)}</span> · {t(T.menu.legal)} {t(T.extras.payments)}: {t(PAYMENTS.currencies)}, {PAYMENTS.cards.join(', ')}.</p>
              <div className="menu-foot-actions">
                {CONTACT.menuUrl && <a className="btn btn-navy" href={CONTACT.menuUrl} target="_blank" rel="noopener noreferrer"><span>{t(T.menu.full)}</span></a>}
                <button type="button" className="btn btn-navy" onClick={() => { onClose(); openBooking() }}><span>{t(T.nav.reserve)}</span></button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
