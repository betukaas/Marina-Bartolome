import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { useMemo, useRef } from 'react'
import { T } from '../data/site'
import { useLang } from '../lib/i18n'
import { hhmm, suggestedArrival, upcomingSunsets } from '../lib/sun'
import { bookingMessage, waLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'
import { MaskText } from './MaskText'
import { Reveal } from './Reveal'

/**
 * Reserva para el atardecer: calcula la puesta de sol de hoy en Isla Mujeres,
 * sugiere una hora de llegada y abre WhatsApp con la reservación prellenada.
 * El sol baja hacia el horizonte conforme se desplaza la página.
 */
export function Sunset() {
  const { t, lang } = useLang()
  const s = T.sunset
  const reduce = useReducedMotion()
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const sunY = useTransform(scrollYProgress, [0.1, 0.75], reduce ? ['40%', '40%'] : ['0%', '78%'])
  const glow = useTransform(scrollYProgress, [0.1, 0.75], [0.35, 1])

  const days = useMemo(() => upcomingSunsets(4), [])
  const first = days[0]
  const arrive = suggestedArrival(first.sunset)
  const locale = lang === 'es' ? 'es-MX' : 'en-US'
  const dayLabel = first.date.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'America/Cancun' })
  const href = waLink(bookingMessage(lang, { date: dayLabel, time: arrive, notes: t(s.comment) }))

  return (
    <section className="sunset" ref={ref} aria-labelledby="sunset-title">
      <div className="sunset-sky" aria-hidden>
        <motion.div className="sunset-sun" style={{ top: sunY, opacity: glow }} />
        <div className="sunset-sea" />
      </div>
      <div className="wrap sunset-grid">
        <div>
          <p className="eyebrow" id="sunset-title">{t(s.eyebrow)}</p>
          <Reveal>
            <p className="sunset-label">{t(first.isToday ? s.today : s.tomorrow)}</p>
          </Reveal>
          <MaskText as="p" className="sunset-time" lines={[hhmm(first.sunset)]} />
          <Reveal delay={0.2}>
            <p className="sunset-arrive">{t(s.arrive).replace('{t}', arrive)}</p>
          </Reveal>
          {href && (
            <Reveal delay={0.3}>
              <a className="btn btn-wa" href={href} target="_blank" rel="noopener noreferrer">
                <WhatsAppIcon size={20} /><span>{t(s.cta)}</span>
              </a>
            </Reveal>
          )}
        </div>
        <Reveal delay={0.25} className="sunset-next">
          <p className="sunset-next-title">{t(s.next)}</p>
          <ul>
            {days.slice(1).map((d) => (
              <li key={d.date.toISOString()}>
                <span>{d.date.toLocaleDateString(locale, { weekday: 'long', day: 'numeric', timeZone: 'America/Cancun' })}</span>
                <b>{hhmm(d.sunset)}</b>
              </li>
            ))}
          </ul>
          <p className="sunset-note">{t(s.note)}</p>
        </Reveal>
      </div>
    </section>
  )
}
