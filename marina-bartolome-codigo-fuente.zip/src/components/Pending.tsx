import { SHOW_PENDING_MARKERS, T } from '../data/site'
import { useLang } from '../lib/i18n'

/** Marcador visible para datos que el restaurante aún debe confirmar. */
export function Pending({ label }: { label?: string }) {
  const { t } = useLang()
  if (!SHOW_PENDING_MARKERS) return null
  return <span className="pending" title={label}>{t(T.pending)}</span>
}
