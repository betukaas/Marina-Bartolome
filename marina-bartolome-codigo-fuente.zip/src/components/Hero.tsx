import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { useRef } from 'react'
import { HERO_VIDEO, IMG, T } from '../data/site'
import { useLang } from '../lib/i18n'
import { EASE_OUT } from '../lib/motion'
import { useMedia } from '../lib/useMedia'
import { MaskText } from './MaskText'
import { Picture, src } from './Picture'
import { QuickBook } from './QuickBook'

export function Hero({ ready, onMenu }: { ready: boolean; onMenu: () => void }) {
  const { t } = useLang()
  const reduce = useReducedMotion()
  // En celular el movimiento ligado al scroll se reduce para que la página se sienta firme
  const touch = useMedia('(hover: none), (pointer: coarse)')
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  // Al salir de la portada la imagen se acerca y el texto se desvanece hacia arriba
  const scale = useTransform(scrollYProgress, [0, 1], [1, reduce ? 1 : touch ? 1.05 : 1.18])
  const y = useTransform(scrollYProgress, [0, 1], ['0%', reduce ? '0%' : touch ? '6%' : '18%'])
  const fade = useTransform(scrollYProgress, [0, 0.6], [1, 0])
  const lift = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : touch ? -30 : -120])
  const saveData = typeof navigator !== 'undefined' && (navigator as Navigator & { connection?: { saveData?: boolean } }).connection?.saveData

  return (
    <section className="hero" id="inicio" ref={ref} aria-label="Marina Bartolomé">
      <motion.div className="hero-media" style={{ scale, y }}>
        {/* Movimiento de cámara lento al entrar */}
        <motion.div
          className="hero-media-in"
          initial={{ scale: touch ? 1.08 : 1.22 }}
          animate={{ scale: ready ? 1.02 : touch ? 1.08 : 1.22 }}
          transition={{ duration: reduce ? 0 : 3.4, ease: EASE_OUT }}
        >
          {HERO_VIDEO && !saveData ? (
            <video autoPlay muted loop playsInline preload="metadata" poster={src(IMG.portadaPanorama)} aria-hidden>
              {HERO_VIDEO.webm && <source src={HERO_VIDEO.webm} type="video/webm" />}
              <source src={HERO_VIDEO.mp4} type="video/mp4" />
            </video>
          ) : (
            <Picture img={IMG.portada} wide={IMG.portadaPanorama} wideMedia="(min-aspect-ratio: 1/1)" priority sizes="100vw" />
          )}
        </motion.div>
      </motion.div>
      <div className="hero-shade" aria-hidden />

      <motion.div className="hero-content wrap" style={{ opacity: fade, y: lift }}>
        <motion.p className="eyebrow" initial={{ opacity: 0, y: 14 }} animate={ready ? { opacity: 1, y: 0 } : {}} transition={{ duration: 1, delay: 0.2, ease: EASE_OUT }}>
          {t(T.hero.eyebrow)}
        </motion.p>
        <MaskText as="h1" className="hero-title" play={ready} delay={0.3} lines={[t(T.hero.line1), <em key="e">{t(T.hero.line2)}</em>]} />
        <motion.div className="hero-foot" initial={{ opacity: 0, y: 20 }} animate={ready ? { opacity: 1, y: 0 } : {}} transition={{ duration: 1.1, delay: 0.9, ease: EASE_OUT }}>
          <p className="hero-sub">{t(T.hero.sub)}</p>
          <div className="hero-actions">
            <QuickBook />
            <button type="button" className="hero-menu-link" onClick={onMenu}>{t(T.hero.ctaMenu)} <span aria-hidden>→</span></button>
          </div>
        </motion.div>
      </motion.div>

      <motion.div className="scroll-cue-wrap" style={{ opacity: fade }}>
        <motion.a href="#cocina" className="scroll-cue" initial={{ opacity: 0 }} animate={ready ? { opacity: 1 } : {}} transition={{ delay: 1.6, duration: 1 }}>
          <span>{t(T.hero.scroll)}</span>
          <i aria-hidden />
        </motion.a>
      </motion.div>
    </section>
  )
}
