import { motion } from 'motion/react'
import type { ElementType, ReactNode } from 'react'
import { DUR, EASE_OUT, viewportOnce } from '../lib/motion'

type Props = {
  lines: ReactNode[]
  as?: ElementType
  className?: string
  delay?: number
  /** Controla la animación desde fuera (p. ej. al terminar la intro) en lugar de al entrar en pantalla */
  play?: boolean
}

/**
 * Titular que se revela línea por línea a través de una máscara.
 * El disparador de visibilidad va en un contenedor sin recorte: si lo pusiéramos en
 * la línea enmascarada, el navegador nunca la vería "en pantalla".
 */
export function MaskText({ lines, as: Tag = 'h2', className, delay = 0, play }: Props) {
  const trigger = play === undefined ? { whileInView: 'show', viewport: viewportOnce } : { animate: play ? 'show' : 'hide' }
  return (
    <Tag className={className}>
      <motion.span className="mask-group" initial="hide" {...trigger}>
        {lines.map((line, i) => (
          <span className="mask-line" key={i}>
            <motion.span
              className="mask-inner"
              variants={{ hide: { y: '110%' }, show: { y: '0%' } }}
              transition={{ duration: DUR.slow, ease: EASE_OUT, delay: delay + i * 0.12 }}
            >
              {line}
            </motion.span>
          </span>
        ))}
      </motion.span>
    </Tag>
  )
}
