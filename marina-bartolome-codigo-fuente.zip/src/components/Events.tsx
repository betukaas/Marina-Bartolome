import { useState } from 'react'
import { IMG, T } from '../data/site'
import { useLang } from '../lib/i18n'
import { eventMessage, waLink } from '../lib/whatsapp'
import { WhatsAppIcon } from './Icons'
import { MaskText } from './MaskText'
import { Picture } from './Picture'
import { ImageReveal, Reveal } from './Reveal'

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

/** Eventos y grupos: el cliente elige qué celebra y se abre WhatsApp con la solicitud prellenada. */
export function Events() {
  const { t, lang } = useLang()
  const e = T.events
  const [type, setType] = useState<number | null>(null)
  const [guests, setGuests] = useState('')
  const [date, setDate] = useState('')
  const [details, setDetails] = useState('')

  const dateLabel = date
    ? new Date(`${date}T12:00:00`).toLocaleDateString(lang === 'es' ? 'es-MX' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    : ''
  const href = waLink(eventMessage(lang, { type: type === null ? '' : t(e.types[type]), guests, date: dateLabel, details }))

  return (
    <section className="events surface-navy" id="eventos" aria-labelledby="events-title">
      <div className="wrap events-grid">
        <ImageReveal className="events-media">
          <Picture img={IMG.torre} sizes="(min-width: 960px) 42vw, 92vw" />
        </ImageReveal>

        <div className="events-body">
          <p className="eyebrow" id="events-title">{t(e.eyebrow)}</p>
          <MaskText className="display display-pearl" lines={[t(e.title1), <em key="e">{t(e.title2)}</em>]} />
          <Reveal delay={0.1}><p className="lead">{t(e.lead)}</p></Reveal>

          <Reveal delay={0.2} className="events-form">
            <p className="events-label">{t(e.typeLabel)}</p>
            <div className="events-types" role="radiogroup" aria-label={t(e.typeLabel)}>
              {e.types.map((ty, i) => (
                <button key={i} type="button" role="radio" aria-checked={type === i} onClick={() => setType(type === i ? null : i)}>
                  {t(ty)}
                </button>
              ))}
            </div>
            <div className="events-fields">
              <div className="field">
                <label htmlFor="ev-guests">{t(e.guests)}</label>
                <input id="ev-guests" type="number" inputMode="numeric" min={2} max={300} value={guests} onChange={(ev) => setGuests(ev.target.value)} placeholder="12" />
              </div>
              <div className="field">
                <label htmlFor="ev-date">{t(e.date)}</label>
                <input id="ev-date" type="date" min={iso(new Date())} value={date} onChange={(ev) => setDate(ev.target.value)} />
              </div>
              <div className="field field-full">
                <label htmlFor="ev-details">{t(e.details)}</label>
                <input id="ev-details" type="text" value={details} onChange={(ev) => setDetails(ev.target.value)} placeholder={t(e.detailsHint)} />
              </div>
            </div>
            {href && (
              <a className="btn btn-wa" href={href} target="_blank" rel="noopener noreferrer">
                <WhatsAppIcon size={20} /><span>{t(e.cta)}</span>
              </a>
            )}
            <p className="events-note">{t(e.note)}</p>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
