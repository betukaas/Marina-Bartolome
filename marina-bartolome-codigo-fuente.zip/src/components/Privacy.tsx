import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef } from 'react'
import { T } from '../data/site'
import { useLang } from '../lib/i18n'
import { EASE_IN_OUT } from '../lib/motion'

/** Aviso de privacidad en un panel lateral. Cierra con Esc, con el botón o tocando fuera. */
export function Privacy({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t } = useLang()
  const p = T.privacy
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    document.body.style.overflow = 'hidden'
    const id = setTimeout(() => closeRef.current?.focus(), 300)
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', esc)
    return () => { clearTimeout(id); document.body.style.overflow = ''; window.removeEventListener('keydown', esc); prev?.focus?.() }
  }, [open, onClose])

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="privacy-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
          <motion.aside
            className="privacy surface-pearl"
            role="dialog"
            aria-modal="true"
            aria-labelledby="privacy-title"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.7, ease: EASE_IN_OUT }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="privacy-head">
              <h2 id="privacy-title">{t(p.title)}</h2>
              <button ref={closeRef} type="button" className="menu-close" onClick={onClose}>{t(T.nav.close)} <span aria-hidden>×</span></button>
            </div>
            <p className="privacy-updated">{t(p.updated)}</p>
            {p.sections.map((sec, i) => (
              <section key={i}>
                <h3>{t(sec.h)}</h3>
                <p>{t(sec.p)}</p>
              </section>
            ))}
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
