import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef } from 'react'
import { T } from '../data/site'
import { useBooking } from '../lib/booking'
import { useLang } from '../lib/i18n'
import { EASE_IN_OUT } from '../lib/motion'
import { Reservation } from './Reservation'

/** Panel de reserva disponible desde cualquier parte del sitio (lateral en escritorio, hoja inferior en móvil). */
export function BookingDrawer({ onPrivacy }: { onPrivacy: () => void }) {
  const { t } = useLang()
  const { open, prefill, closeBooking } = useBooking()
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    if (!open) return
    const prev = document.activeElement as HTMLElement | null
    document.body.style.overflow = 'hidden'
    const id = setTimeout(() => closeRef.current?.focus(), 350)
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && closeBooking()
    window.addEventListener('keydown', esc)
    return () => { clearTimeout(id); document.body.style.overflow = ''; window.removeEventListener('keydown', esc); prev?.focus?.() }
  }, [open, closeBooking])

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="drawer-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={closeBooking}>
          <motion.aside
            className="booking-drawer surface-navy"
            role="dialog"
            aria-modal="true"
            aria-label={t(T.booking.open)}
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.7, ease: EASE_IN_OUT }}
            onClick={(e) => e.stopPropagation()}
          >
            <button ref={closeRef} type="button" className="menu-close drawer-close" onClick={closeBooking}>{t(T.nav.close)} <span aria-hidden>×</span></button>
            <Reservation onPrivacy={onPrivacy} prefill={prefill} idPrefix="rd" />
          </motion.aside>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
