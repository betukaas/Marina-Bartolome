import { motion, useMotionValue, useSpring } from 'motion/react'
import { useEffect, useState } from 'react'
import { useMedia } from '../lib/useMedia'

/**
 * Cursor discreto para escritorio: un punto y un anillo que sigue con retraso.
 * Crece sobre elementos interactivos y muestra una etiqueta en los que tienen data-cursor.
 * No se monta en pantallas táctiles ni con movimiento reducido.
 */
export function Cursor() {
  const fine = useMedia('(hover: hover) and (pointer: fine)')
  const reduce = useMedia('(prefers-reduced-motion: reduce)')
  const x = useMotionValue(-100)
  const y = useMotionValue(-100)
  const rx = useSpring(x, { stiffness: 380, damping: 32, mass: 0.5 })
  const ry = useSpring(y, { stiffness: 380, damping: 32, mass: 0.5 })
  const [state, setState] = useState<{ hover: boolean; label: string; hidden: boolean }>({ hover: false, label: '', hidden: true })

  useEffect(() => {
    if (!fine || reduce) return
    document.documentElement.classList.add('has-cursor')
    const move = (e: PointerEvent) => {
      x.set(e.clientX); y.set(e.clientY)
      const el = (e.target as Element | null)?.closest?.('a, button, [data-cursor], input, select, textarea, label')
      const label = el?.getAttribute('data-cursor') ?? ''
      setState((s) => (s.hover === !!el && s.label === label && !s.hidden ? s : { hover: !!el, label, hidden: false }))
    }
    const leave = () => setState((s) => ({ ...s, hidden: true }))
    window.addEventListener('pointermove', move)
    document.addEventListener('pointerleave', leave)
    return () => {
      document.documentElement.classList.remove('has-cursor')
      window.removeEventListener('pointermove', move)
      document.removeEventListener('pointerleave', leave)
    }
  }, [fine, reduce, x, y])

  if (!fine || reduce) return null
  const big = state.label ? 84 : state.hover ? 52 : 34
  return (
    <>
      <motion.div className="cursor-dot" style={{ x, y, opacity: state.hidden || state.label ? 0 : 1 }} aria-hidden />
      <motion.div
        className={`cursor-ring ${state.label ? 'has-label' : ''}`}
        style={{ x: rx, y: ry, opacity: state.hidden ? 0 : 1 }}
        animate={{ width: big, height: big }}
        transition={{ type: 'spring', stiffness: 300, damping: 26 }}
        aria-hidden
      >
        {state.label && <span>{state.label}</span>}
      </motion.div>
    </>
  )
}
