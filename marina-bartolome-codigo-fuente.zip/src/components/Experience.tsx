import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { useRef } from 'react'
import { IMG, T } from '../data/site'
import { useLang } from '../lib/i18n'
import { useMedia } from '../lib/useMedia'
import { MaskText } from './MaskText'
import { Pending } from './Pending'
import { Picture } from './Picture'
import { ImageReveal, Reveal } from './Reveal'

/** Composición editorial asimétrica: tres fotos a distintas escalas y velocidades. */
export function Experience() {
  const { t } = useLang()
  const reduce = useReducedMotion()
  const touch = useMedia('(hover: none), (pointer: coarse)')
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const slow = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : touch ? [16, -16] : [60, -60])
  const fast = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : touch ? [30, -30] : [140, -140])
  const e = T.experience

  return (
    <section className="experience surface-sand" id="experiencia" ref={ref}>
      <div className="wrap">
        <header className="section-head section-head-split">
          <div>
            <p className="eyebrow eyebrow-dark">{t(e.eyebrow)}</p>
            <MaskText className="display" lines={[t(e.title1), <em key="e">{t(e.title2)}</em>]} />
          </div>
        </header>

        <div className="exp-grid">
          <motion.figure className="exp-a" style={{ y: slow }}>
            <ImageReveal><Picture img={IMG.atardecer} sizes="(min-width: 960px) 40vw, 92vw" /></ImageReveal>
            <figcaption>{t(e.blocks[0].title)}</figcaption>
          </motion.figure>
          <motion.figure className="exp-b" style={{ y: fast }}>
            <ImageReveal from="right" delay={0.15}><Picture img={IMG.mesa} sizes="(min-width: 960px) 30vw, 60vw" /></ImageReveal>
            <figcaption>{t(e.blocks[1].title)}</figcaption>
          </motion.figure>

          <div className="exp-texts">
            {e.blocks.map((b, i) => (
              <Reveal key={i} delay={i * 0.1} className="exp-text">
                <h3>{t(b.title)}</h3>
                <p>{t(b.text)}</p>
              </Reveal>
            ))}
          </div>
        </div>

        <div className="story">
          <Reveal className="story-head">
            <p className="eyebrow eyebrow-dark">{t(e.storyKicker)}</p>
            <h3>{t(e.storyTitle)} {e.storyPending && <Pending />}</h3>
            <ul className="story-values">
              {e.values.map((val, i) => <li key={i}>{t(val)}</li>)}
            </ul>
          </Reveal>
          <div className="story-body">
            {e.story.map((para, i) => (
              <Reveal key={i} delay={i * 0.12}><p className={i === 0 ? 'story-lead' : ''}>{t(para)}</p></Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
