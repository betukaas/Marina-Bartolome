import { useState, type CSSProperties } from 'react'
import type { Img } from '../data/site'
import { useLang } from '../lib/i18n'

const BASE = import.meta.env.BASE_URL

export const src = (img: Img, w = img.widths[img.widths.length - 1], ext = 'webp') => `${BASE}images/${img.name}-${w}.${ext}`
const srcSet = (img: Img, ext: string) => img.widths.map((w) => `${src(img, w, ext)} ${w}w`).join(', ')

type Props = {
  img: Img
  sizes?: string
  priority?: boolean
  className?: string
  style?: CSSProperties
  /** Imagen alternativa para pantallas anchas (dirección de arte) */
  wide?: Img
  wideMedia?: string
  decorative?: boolean
}

/** Imagen responsiva AVIF/WebP con dimensiones explícitas y respaldo si falla la carga. */
export function Picture({ img, sizes = '100vw', priority, className, style, wide, wideMedia = '(min-width: 900px)', decorative }: Props) {
  const { t } = useLang()
  const [failed, setFailed] = useState(false)
  if (failed) return <div className={`img-fallback ${className ?? ''}`} style={style} role={decorative ? undefined : 'img'} aria-label={decorative ? undefined : t(img.alt)} />
  return (
    <picture className={className} style={style}>
      {wide && <source media={wideMedia} type="image/avif" srcSet={srcSet(wide, 'avif')} sizes={sizes} />}
      {wide && <source media={wideMedia} type="image/webp" srcSet={srcSet(wide, 'webp')} sizes={sizes} />}
      <source type="image/avif" srcSet={srcSet(img, 'avif')} sizes={sizes} />
      <img
        src={src(img)}
        srcSet={srcSet(img, 'webp')}
        sizes={sizes}
        width={img.width}
        height={img.height}
        alt={decorative ? '' : t(img.alt)}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={priority ? 'high' : 'auto'}
        onError={() => setFailed(true)}
      />
    </picture>
  )
}
