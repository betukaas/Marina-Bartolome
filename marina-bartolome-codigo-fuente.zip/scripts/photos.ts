/**
 * Fotos cambiadas desde el panel /admin.
 *
 * El panel guarda la foto original en public/uploads/ y anota su ruta en src/content/fotos.json.
 * Al compilar, este plugin la recorta al formato de cada lugar donde se usa (vertical, panorámica…)
 * y genera las versiones AVIF/WebP con los mismos nombres que usa el sitio, así que el diseño
 * no cambia aunque la foto nueva tenga otro tamaño. Las originales no se publican.
 */
import fs from 'node:fs'
import path from 'node:path'
import sharp from 'sharp'
import type { Plugin } from 'vite'
import fotos from '../src/content/fotos.json'
import { IMG } from '../src/data/site'

/** Cada foto del panel alimenta una o más imágenes del sitio */
const GROUPS: Record<keyof typeof fotos, (keyof typeof IMG)[]> = {
  portada: ['portada', 'portadaPanorama'],
  fachada: ['fachada', 'fachadaPanorama'],
  atardecer: ['atardecer', 'atardecerPanorama'],
  mesa: ['mesa'],
  pulpo: ['pulpo'],
  camarones: ['camarones'],
  pescado: ['pescado'],
  langosta: ['langosta'],
  stack: ['stack'],
  torre: ['torre'],
  coctel: ['coctel'],
  ginPepino: ['ginPepino'],
}

export function photos(): Plugin {
  let outDir = 'dist'
  let root = process.cwd()
  return {
    name: 'marina-photos',
    apply: 'build',
    configResolved(c) {
      root = c.root
      outDir = path.resolve(c.root, c.build.outDir)
    },
    async closeBundle() {
      for (const [key, photo] of Object.entries(fotos) as [keyof typeof fotos, (typeof fotos)[keyof typeof fotos]][]) {
        if (!photo.file) continue
        const source = path.join(root, 'public', photo.file.replace(/^\.?\//, ''))
        if (!fs.existsSync(source)) {
          this.warn(`Foto "${key}": no se encontró ${photo.file}, se conserva la original`)
          continue
        }
        for (const name of GROUPS[key]) {
          const img = IMG[name]
          for (const w of img.widths) {
            const h = Math.round((w * img.height) / img.width)
            // rotate() respeta la orientación de las fotos tomadas con celular
            const base = sharp(source).rotate().resize(w, h, { fit: 'cover', position: 'attention' })
            await base.clone().webp({ quality: 80 }).toFile(path.join(outDir, 'images', `${img.name}-${w}.webp`))
            await base.clone().avif({ quality: 55 }).toFile(path.join(outDir, 'images', `${img.name}-${w}.avif`))
          }
        }
        console.log(`  foto actualizada: ${key}`)
      }
      // Las fotos originales del panel pesan mucho y el sitio no las usa
      fs.rmSync(path.join(outDir, 'uploads'), { recursive: true, force: true })
    },
  }
}
