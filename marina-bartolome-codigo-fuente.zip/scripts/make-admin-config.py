"""Genera public/admin/config.yml, la configuración del panel privado /admin (Sveltia CMS).

Uso: python3 scripts/make-admin-config.py

Se edita aquí (no a mano en el YAML) para que los campos en español/inglés queden iguales en
todo el panel. Cambia REPO por el repositorio de GitHub donde vive el sitio.
"""
from pathlib import Path
import json
import yaml

ROOT = Path(__file__).resolve().parent.parent
REPO = "TU-USUARIO-DE-GITHUB/marina-bartolome"
BRANCH = "main"

SECTIONS = json.loads((ROOT / "src/content/carta.json").read_text())["sections"]

# Fotos del sitio: clave en fotos.json -> dónde aparece
PHOTOS = {
    "portada": "Portada (la primera foto que se ve al entrar)",
    "fachada": "Fachada y muelle (tarjeta del mapa)",
    "atardecer": "Atardecer en el muelle (sección Experiencia)",
    "mesa": "Mesa con platillos (Experiencia y carta: Especialidades)",
    "pulpo": "Pulpo (favoritos)",
    "camarones": "Camarones zarandeados (favoritos)",
    "pescado": "Pescado entero zarandeado (favoritos)",
    "langosta": "Langosta (favoritos y carta)",
    "stack": "Seafood stack (favoritos)",
    "torre": "Torre de atún con Purple Spritz (Eventos y carta)",
    "coctel": "Purple Spritz (favoritos)",
    "ginPepino": "Coctel de gin con pepino (carta: Bar)",
}
PHOTO_OPTIONS = [{"label": label.split(" (")[0], "value": key} for key, label in PHOTOS.items()]


def L(name, label, text=False, required=True, hint=None):
    """Texto en español e inglés. Si el inglés se deja vacío, se usa el español."""
    w = "text" if text else "string"
    f = {
        "name": name, "label": label, "widget": "object", "required": required,
        "fields": [
            {"name": "es", "label": "Español", "widget": w, "required": required},
            {"name": "en", "label": "Inglés", "widget": w, "required": False},
        ],
    }
    if hint:
        f["hint"] = hint
    return f


def s(name, label, hint=None, required=True, widget="string"):
    f = {"name": name, "label": label, "widget": widget, "required": required}
    if hint:
        f["hint"] = hint
    return f


def b(name, label, hint=None):
    f = {"name": name, "label": label, "widget": "boolean", "default": False, "required": False}
    if hint:
        f["hint"] = hint
    return f


def photo_select(name="photo", label="Foto"):
    return {"name": name, "label": label, "widget": "select", "options": PHOTO_OPTIONS,
            "hint": "Las fotos se cambian en «Fotos del sitio»."}


dish_fields = [
    L("name", "Nombre del platillo"),
    L("desc", "Descripción", text=True, required=False),
    s("price", "Precio", hint="Como en la carta: $565 · $2.70 / g · $60 – $130"),
    b("star", "★ Platillo estrella"),
    b("local", "🌴 Cocina local"),
    L("note", "Nota corta", required=False, hint="Opcional: temporada, premio, «al ajo o al guajillo»…"),
]

negocio = {
    "name": "negocio", "label": "Contacto, horario y redes", "file": "src/content/negocio.json", "format": "json",
    "fields": [
        {"name": "contact", "label": "Contacto", "widget": "object", "fields": [
            s("phone", "Teléfono", hint="Como se muestra: 998 234 2257"),
            s("whatsapp", "WhatsApp de reservaciones", hint="Con lada del país: +52 998 181 3378. A este número llegan todas las reservas."),
            s("address", "Dirección"),
            s("locality", "Código postal, ciudad y estado"),
            s("mapsUrl", "Enlace de Google Maps", hint="El de «Compartir» en la ficha de Google Maps"),
        ]},
        {"name": "hours", "label": "Horario", "widget": "list", "summary": "{{fields.days.es}}: {{fields.hours}}", "fields": [
            L("days", "Días", hint="Ej. Lunes a domingo"),
            s("hours", "Horas", hint="Ej. 11:00 – 20:00"),
        ]},
        {"name": "booking", "label": "Horas para reservar", "widget": "object", "fields": [
            s("first", "Primera hora", hint="Formato 24 h: 11:00"),
            s("last", "Última hora", hint="Formato 24 h: 19:30"),
        ]},
        {"name": "payments", "label": "Formas de pago", "widget": "object", "fields": [
            L("currencies", "Monedas"),
            {"name": "cards", "label": "Tarjetas", "widget": "list", "field": s("card", "Tarjeta")},
        ]},
        {"name": "localsOffer", "label": "Descuento para isleños", "widget": "object", "fields": [
            {"name": "percent", "label": "Porcentaje", "widget": "number", "value_type": "int", "min": 0, "max": 100},
        ]},
        {"name": "social", "label": "Redes sociales", "widget": "list", "summary": "{{fields.label}}", "fields": [
            s("label", "Red", hint="Instagram, Facebook, Tripadvisor, Linktree… Con esos nombres exactos sale su ícono."),
            s("handle", "Cómo se muestra", hint="Ej. @marina_bartolomeisla"),
            s("url", "Enlace"),
        ]},
    ],
}

carta = {
    "name": "carta", "label": "Carta y precios", "file": "src/content/carta.json", "format": "json",
    "fields": [{
        "name": "sections", "label": "Secciones de la carta", "widget": "list", "summary": "{{fields.title.es}}",
        "fields": [
            s("id", "Identificador", hint="En minúsculas y sin espacios (ej. barra-fria). No lo cambies en secciones existentes."),
            L("title", "Nombre de la sección"),
            L("intro", "Introducción", text=True),
            photo_select(),
            {"name": "groups", "label": "Grupos", "widget": "list", "summary": "{{fields.title.es}}", "fields": [
                L("title", "Nombre del grupo", hint="Ej. Pulpo, Camarón, Ceviches"),
                L("note", "Nota del grupo", required=False, hint="Opcional: porción o forma de servir"),
                b("local", "🌴 Grupo de cocina local"),
                {"name": "items", "label": "Platillos", "widget": "list", "summary": "{{fields.name.es}} · {{fields.price}}", "fields": dish_fields},
            ]},
        ],
    }],
}

favoritos = {
    "name": "favoritos", "label": "Favoritos de la casa", "file": "src/content/favoritos.json", "format": "json",
    "fields": [{
        "name": "dishes", "label": "Platillos favoritos", "widget": "list", "summary": "{{fields.name.es}} · {{fields.price}}",
        "hint": "Las tarjetas grandes con foto del inicio. Arrastra para cambiar el orden.",
        "fields": dish_fields[:4] + [dish_fields[5], photo_select(), {
            "name": "menuId", "label": "Sección de la carta que abre", "widget": "select",
            "options": [{"label": x["title"]["es"], "value": x["id"]} for x in SECTIONS],
        }],
    }],
}

resenas = {
    "name": "resenas", "label": "Reseñas", "file": "src/content/resenas.json", "format": "json",
    "fields": [{
        "name": "reviews", "label": "Reseñas de Google", "widget": "list", "summary": "{{fields.author}}",
        "hint": "Solo reseñas reales, copiadas tal cual de Google Maps.",
        "fields": [
            s("author", "Nombre", hint="Como aparece en Google, ej. Hugo C."),
            s("badge", "Distintivo", required=False, hint="Opcional: Local Guide"),
            {"name": "rating", "label": "Estrellas", "widget": "number", "value_type": "int", "min": 1, "max": 5, "default": 5},
            {"name": "lang", "label": "Idioma de la reseña", "widget": "select", "default": "es",
             "options": [{"label": "Español", "value": "es"}, {"label": "Inglés", "value": "en"}]},
            b("scores", "Mostrar «Comida 5 · Servicio 5 · Ambiente 5»"),
            s("when", "Fecha", required=False, hint="Opcional: Septiembre 2026"),
            s("text", "Texto de la reseña", widget="text"),
        ],
    }],
}

fotos = {
    "name": "fotos", "label": "Fotos del sitio", "file": "src/content/fotos.json", "format": "json",
    "fields": [
        {"name": key, "label": label, "widget": "object", "collapsed": True, "fields": [
            {"name": "file", "label": "Foto nueva", "widget": "image", "required": False,
             "hint": "Sube la foto en buena calidad (JPG o PNG). Se recorta y optimiza sola. Déjala vacía para usar la original."},
            L("alt", "Qué se ve en la foto", required=False, hint="Para Google y personas con discapacidad visual. Ej. Pulpo a la brasa con puré"),
        ]}
        for key, label in PHOTOS.items()
    ],
}

textos = {
    "name": "textos", "label": "Textos principales", "file": "src/content/textos.json", "format": "json",
    "fields": [
        {"name": "hero", "label": "Portada", "widget": "object", "collapsed": True, "fields": [
            L("eyebrow", "Texto pequeño de arriba"), L("line1", "Título, línea 1"), L("line2", "Título, línea 2 (dorada)"), L("sub", "Frase", text=True),
        ]},
        {"name": "manifesto", "label": "Frase grande", "widget": "object", "collapsed": True, "fields": [L("text", "Texto", text=True)]},
        {"name": "cuisine", "label": "La cocina", "widget": "object", "collapsed": True, "fields": [
            L("title1", "Título, línea 1"), L("title2", "Título, línea 2"), L("lead", "Introducción", text=True),
        ]},
        {"name": "experience", "label": "Experiencia e historia", "widget": "object", "collapsed": True, "fields": [
            L("title1", "Título, línea 1"), L("title2", "Título, línea 2"),
            {"name": "story", "label": "Nuestra historia (párrafos)", "widget": "list", "summary": "{{fields.es}}",
             "fields": [s("es", "Español", widget="text"), s("en", "Inglés", widget="text", required=False)]},
            {"name": "values", "label": "Valores", "widget": "list", "summary": "{{fields.es}}",
             "fields": [s("es", "Español"), s("en", "Inglés", required=False)]},
        ]},
        {"name": "events", "label": "Eventos y grupos", "widget": "object", "collapsed": True, "fields": [
            L("title1", "Título, línea 1"), L("title2", "Título, línea 2"), L("lead", "Introducción", text=True),
        ]},
        {"name": "visit", "label": "Visítanos", "widget": "object", "collapsed": True, "fields": [
            L("title1", "Título, línea 1"), L("title2", "Título, línea 2"),
        ]},
    ],
}

config = {
    "backend": {"name": "github", "repo": REPO, "branch": BRANCH, "commit_messages": {"update": "Actualizar {{slug}} desde el panel"}},
    "media_folder": "public/uploads",
    "public_folder": "/uploads",
    "display_url": "/",
    "collections": [
        {"name": "contenido", "label": "Contenido del sitio", "files": [carta, favoritos, fotos, negocio, resenas, textos]},
    ],
}

out = ROOT / "public/admin/config.yml"
out.parent.mkdir(parents=True, exist_ok=True)
header = "# Generado con scripts/make-admin-config.py — edita ese archivo y vuelve a correrlo.\n"
out.write_text(header + yaml.safe_dump(config, allow_unicode=True, sort_keys=False, width=1000))
print("listo:", out)
