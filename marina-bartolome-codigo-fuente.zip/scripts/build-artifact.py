"""Prepara dist/artifact.html (página sin esqueleto html/head/body) y lista los archivos a publicar."""
import json, os, re
from pathlib import Path

DIST = Path(__file__).resolve().parent.parent / "dist"
s = (DIST / "index.html").read_text()
s = re.sub(r"<!doctype html>\s*<html[^>]*>\s*<head>", "", s, flags=re.I)
s = re.sub(r"</head>\s*<body>", "", s)
s = re.sub(r"</body>\s*</html>\s*$", "", s)
s = re.sub(r"<meta charset[^>]*>\s*", "", s)
s = re.sub(r'<meta name="viewport"[^>]*>\s*', "", s)
s = re.sub(r"<title>[^<]*</title>", '<title>Marina Bartolomé</title>\n    <meta name="claude:viewport-fit-sides" content="cover">', s, count=1)
(DIST / "artifact.html").write_text(s.strip() + "\n")
files = sorted(str(p.relative_to(DIST)) for p in DIST.rglob("*") if p.is_file() and p.name not in ("index.html", "artifact.html") and not p.name.endswith(".png") or p.name == "favicon.png")
print(json.dumps([{"path": f} for f in files if not f.startswith("images/") or "images/" in f]))
