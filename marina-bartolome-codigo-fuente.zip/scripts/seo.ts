/**
 * SEO generado en la compilación a partir de src/data/site.ts, para que Google lea
 * el restaurante, el horario, la ubicación y la carta con precios sin ejecutar JavaScript.
 * Solo usa datos confirmados del restaurante.
 */
import type { Plugin } from 'vite'
import { CONTACT, GEO, IMG, MENU, PAYMENTS, SITE_URL, SOCIAL } from '../src/data/site'

const abs = (path: string) => (SITE_URL ? `${SITE_URL}/${path}` : `./${path}`)

function restaurant() {
  const priced = (p: string) => /^\$[\d,]+$/.test(p.trim())
  const menu = {
    '@type': 'Menu',
    name: 'Carta Marina Bartolomé',
    inLanguage: ['es', 'en'],
    hasMenuSection: MENU.map((s) => ({
      '@type': 'MenuSection',
      name: s.title.es,
      description: s.intro.es,
      hasMenuItem: s.groups.flatMap((g) =>
        g.items.map((it) => ({
          '@type': 'MenuItem',
          name: it.name.es,
          ...(it.desc ? { description: it.desc.es } : {}),
          ...(priced(it.price) ? { offers: { '@type': 'Offer', price: it.price.replace(/[$,]/g, ''), priceCurrency: 'MXN' } } : {}),
        })),
      ),
    })),
  }

  return {
    '@context': 'https://schema.org',
    '@type': ['Restaurant', 'BarOrPub'],
    '@id': abs('#restaurante'),
    ...(SITE_URL ? { url: `${SITE_URL}/` } : {}),
    name: 'Marina Bartolomé',
    alternateName: 'Marina Bartolomé Isla Mujeres',
    description: 'Restaurante de mariscos, bar y marina sobre el agua en Isla Mujeres Centro. Pulpo tatemado, camarones zarandeados, raw bar, langosta y coctelería frente al mar.',
    image: [abs('images/og-marina-bartolome.jpg'), abs(`images/${IMG.portada.name}-${IMG.portada.width}.webp`), abs(`images/${IMG.mesa.name}-${IMG.mesa.width}.webp`)],
    logo: abs('images/logo-marino-512.webp'),
    telephone: CONTACT.phoneIntl,
    acceptsReservations: true,
    servesCuisine: ['Mariscos', 'Seafood', 'Cocina mexicana'],
    currenciesAccepted: 'MXN, USD',
    paymentAccepted: ['Efectivo', ...PAYMENTS.cards].join(', '),
    address: {
      '@type': 'PostalAddress',
      streetAddress: CONTACT.address,
      postalCode: '77400',
      addressLocality: 'Isla Mujeres',
      addressRegion: 'Quintana Roo',
      addressCountry: 'MX',
    },
    geo: { '@type': 'GeoCoordinates', latitude: GEO.lat, longitude: GEO.lng },
    hasMap: CONTACT.mapsUrl,
    openingHoursSpecification: [{
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      opens: '11:00',
      closes: '20:00',
    }],
    sameAs: SOCIAL.map((s) => s.url).filter(Boolean),
    hasMenu: menu,
  }
}

export function seo(): Plugin {
  return {
    name: 'marina-seo',
    transformIndexHtml(html) {
      const json = JSON.stringify(restaurant(), null, 2).replace(/</g, '\\u003c')
      let out = html.replace('<!-- seo:jsonld -->', `<script type="application/ld+json">\n${json}\n    </script>`)
      if (SITE_URL) {
        out = out
          .replace('<!-- seo:canonical -->', `<link rel="canonical" href="${SITE_URL}/" />\n    <meta property="og:url" content="${SITE_URL}/" />`)
          .replaceAll('content="./images/', `content="${SITE_URL}/images/`)
      }
      return out
    },
    generateBundle() {
      const robots = ['User-agent: *', 'Allow: /', ...(SITE_URL ? [`Sitemap: ${SITE_URL}/sitemap.xml`] : [])].join('\n') + '\n'
      this.emitFile({ type: 'asset', fileName: 'robots.txt', source: robots })
      if (SITE_URL) {
        const today = new Date().toISOString().slice(0, 10)
        this.emitFile({
          type: 'asset',
          fileName: 'sitemap.xml',
          source: `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>${SITE_URL}/</loc><lastmod>${today}</lastmod></url>\n</urlset>\n`,
        })
      }
    },
  }
}
