"""Genera las imágenes optimizadas del sitio a partir de assets-src/.

Uso: python3 scripts/optimize-images.py

- Fotos: versiones AVIF y WebP en varios anchos dentro de public/images/.
- Logo: versiones PNG con fondo transparente en azul marino y en blanco perla.
- Open Graph: imagen 1200x630 para compartir en redes.
"""
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
SRC, OUT = ROOT / "assets-src", ROOT / "public" / "images"
OUT.mkdir(parents=True, exist_ok=True)

# nombre de salida, archivo fuente, recorte opcional (x0, y0, x1, y1), anchos
PHOTOS = [
    ("fachada", "fachada-muelle.jpg", None, [640, 1017]),
    ("fachada-panorama", "fachada-muelle.jpg", (0, 150, 1017, 760), [800, 1017]),
    ("mesa", "mesa-muelle.jpg", None, [640, 1107]),
    ("pulpo", "mesa-muelle.jpg", (150, 760, 900, 1200), [750]),
    ("camarones", "mesa-muelle.jpg", (0, 720, 420, 980), [420]),
    ("langosta", "langosta.jpg", None, [640, 862]),
    ("torre", "torre-atun.jpg", None, [640, 1098]),
    ("coctel", "torre-atun.jpg", (330, 300, 830, 980), [500]),
    ("gin-pepino", "mesa-muelle.jpg", (760, 520, 1107, 1080), [347]),
    ("atardecer", "atardecer-muelle.jpg", None, [640, 1077]),
    ("pescado", "pescado-zarandeado.jpg", None, [640, 1100]),
    ("portada", "fachada-muelle-hd.jpg", None, [640, 1133]),
    ("portada-panorama", "fachada-muelle-hd.jpg", (0, 230, 1133, 900), [800, 1133]),
    ("stack", "torre-atun.jpg", (120, 593, 980, 1453), [860]),
    ("atardecer-panorama", "atardecer-muelle.jpg", (0, 330, 1077, 1000), [800, 1077]),
]

for name, src, box, widths in PHOTOS:
    im = Image.open(SRC / src).convert("RGB")
    if box:
        im = im.crop(box)
    for w in widths:
        r = im if im.width <= w else im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
        r.save(OUT / f"{name}-{w}.avif", quality=60)
        r.save(OUT / f"{name}-{w}.webp", quality=80, method=6)
        print(f"{name}-{w}", r.size)

# Logo: la tinta oscura se convierte en canal alfa para poder colorearlo.
logo = Image.open(SRC / "logo-timon.jpg").convert("L")
alpha = ImageOps.invert(logo).point(lambda v: 0 if v < 40 else min(255, int((v - 40) * 1.35)))
bbox = alpha.getbbox()
alpha = alpha.crop(bbox)
for name, rgb in [("logo-marino", (7, 29, 43)), ("logo-perla", (247, 245, 240))]:
    for size in (160, 512):
        layer = Image.new("RGBA", alpha.size, rgb + (0,))
        layer.putalpha(alpha)
        layer.resize((size, round(alpha.height * size / alpha.width)), Image.LANCZOS).save(OUT / f"{name}-{size}.png", optimize=True)
        layer.resize((size, round(alpha.height * size / alpha.width)), Image.LANCZOS).save(OUT / f"{name}-{size}.webp", quality=90)
# Favicon
fav = Image.new("RGBA", alpha.size, (7, 29, 43, 0)); fav.putalpha(alpha)
fav.resize((64, 64), Image.LANCZOS).save(ROOT / "public" / "favicon.png")

# Open Graph 1200x630
og = Image.open(SRC / "atardecer-muelle.jpg").convert("RGB").crop((0, 330, 1077, 895)).resize((1200, 630), Image.LANCZOS)
og.save(OUT / "og-marina-bartolome.jpg", quality=84, optimize=True, progressive=True)
