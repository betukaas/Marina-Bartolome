"""Separa el logo en capas para animar al capitán girando su timón (intro del sitio).

Capas en public/images/ (todas 1000 px, mismo encuadre, fondo transparente):
  logo-anim-base.webp   logo sin el capitán ni el interior del timón
  logo-anim-body.webp   torso, hombros y brazo derecho con el puño
  logo-anim-head.webp   cabeza con la gorra
  logo-anim-hand.webp   mano izquierda que empuja el timón
El timón se redibuja como vector en src/components/Intro.tsx, que repite estas coordenadas.
Uso: python3 scripts/split-logo.py [--preview salida.png]
"""
import sys
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "assets-src" / "logo-timon-hd.png"
OUT = ROOT / "public" / "images"
SIZE = 1000
NAVY = (28, 34, 59, 255)
WHITE = (251, 252, 253, 255)

# Coordenadas en el logo original (2081 × 2078)
HELM = (905, 1212, 196)          # centro y radio del timón pequeño
HELM_BOTTOM = 1387               # debajo empiezan el borde del medallón y las letras
HELM_BODY = [(1030, 900), (1200, 900), (1200, 1420), (1060, 1420), (1010, 1120)]  # parte del torso delante del timón
off = lambda pts: [(x + 640, y + 640) for x, y in pts]
HEAD = off([(335, 60), (380, 36), (472, 36), (502, 95), (494, 140), (478, 200), (472, 246), (382, 252), (360, 202), (344, 142), (333, 108)])
BODY = off([(272, 214), (350, 194), (382, 246), (472, 250), (490, 194), (588, 204), (648, 258), (690, 345), (704, 440), (694, 524), (652, 564), (612, 566), (604, 640),
            (470, 640), (430, 560), (380, 422), (330, 420), (258, 380), (246, 300)])
HAND = off([(22, 340), (80, 330), (142, 360), (150, 420), (128, 446), (60, 440), (20, 380)])

im = Image.open(SRC).convert("RGBA")
W, H = im.size

def poly_mask(pts, grow=0, blur=1.2):
    """grow > 0 ensancha el recorte (capas), grow < 0 lo encoge (hueco en la base): así no queda costura en reposo"""
    m = Image.new("L", (W, H), 0)
    ImageDraw.Draw(m).polygon(pts, fill=255)
    if grow > 0:
        m = m.filter(ImageFilter.MaxFilter(grow * 2 + 1))
    elif grow < 0:
        m = m.filter(ImageFilter.MinFilter(-grow * 2 + 1))
    return m.filter(ImageFilter.GaussianBlur(blur))

def helm_mask():
    cx, cy, r = HELM
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
    d.rectangle((0, HELM_BOTTOM, W, H), fill=0)
    d.polygon(HELM_BODY, fill=0)
    return m.filter(ImageFilter.GaussianBlur(1.5))

def layer(mask):
    # Solo se recorta la transparencia; el color queda intacto para que los bordes no se oscurezcan
    out = im.copy()
    out.putalpha(ImageChops.multiply(im.getchannel("A"), mask))
    return out

layers = {"body": layer(poly_mask(BODY, 3)), "head": layer(poly_mask(HEAD, 3)), "hand": layer(poly_mask(HAND, 3))}

# Base: donde estaba el capitán queda el fondo blanco del medallón; el disco del timón queda azul
base = im.copy()
for pts in (BODY, HEAD, HAND):
    m = poly_mask(pts, -4)
    base.paste(Image.new("RGBA", (W, H), WHITE), (0, 0), m)
base.paste(Image.new("RGBA", (W, H), NAVY), (0, 0), helm_mask())
layers["base"] = base

for name, img in layers.items():
    img.resize((SIZE, round(H * SIZE / W)), Image.LANCZOS).save(OUT / f"logo-anim-{name}.webp", quality=88)
    print(name, (OUT / f"logo-anim-{name}.webp").stat().st_size // 1024, "KB")

if "--preview" in sys.argv:
    import math
    def frame(body_a, head_a, hand_a):
        f = Image.new("RGBA", (W, H), (247, 245, 240, 255))
        f.alpha_composite(base)
        f.alpha_composite(layers["body"].rotate(body_a, center=(1180, 1280), resample=Image.BICUBIC))
        f.alpha_composite(layers["head"].rotate(head_a, center=(1065, 890), resample=Image.BICUBIC))
        f.alpha_composite(layers["hand"].rotate(hand_a, center=HELM[:2], resample=Image.BICUBIC))
        return f.crop((560, 560, 1500, 1500)).resize((420, 420))
    shots = [frame(0, 0, 0), frame(3, -4, 9), frame(-3, 4, -9)]
    sheet = Image.new("RGB", (1260, 420))
    for i, s in enumerate(shots): sheet.paste(s.convert("RGB"), (i * 420, 0))
    sheet.save(sys.argv[-1])
