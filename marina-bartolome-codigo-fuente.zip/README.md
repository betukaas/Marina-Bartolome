# Marina Bartolomé — sitio web

Sitio de una sola página para Marina Bartolomé (restaurante, bar y marina en Isla Mujeres).
Hecho con React, Vite, TypeScript, Motion para las animaciones y CSS propio.

## Comandos

```bash
npm install
npm run dev       # desarrollo en http://localhost:5173
npm run build     # versión final en dist/
npm run preview   # sirve dist/ para revisarla
python3 scripts/optimize-images.py   # regenera las imágenes AVIF/WebP desde assets-src/
```

## Dónde se cambia cada cosa

**Panel privado:** `/admin` (Sveltia CMS) edita los archivos de `src/content/*.json`.
Instalación y uso en `GUIA-PANEL.md`. La configuración del panel se genera con
`python3 scripts/make-admin-config.py`. Las fotos subidas desde el panel (`public/uploads/`)
se recortan y optimizan al compilar (`scripts/photos.ts`).

| Qué (desde el panel) | Archivo |
| --- | --- |
| Carta y precios | `src/content/carta.json` |
| Favoritos de la casa | `src/content/favoritos.json` |
| Fotos del sitio | `src/content/fotos.json` |
| Contacto, horario, pagos, redes | `src/content/negocio.json` |
| Reseñas | `src/content/resenas.json` |
| Textos principales | `src/content/textos.json` |

El resto vive en `src/data/site.ts`, que une esos archivos con los demás textos:

| Qué | Dónde |
| --- | --- |
| Textos en español e inglés | `T` |
| Video de portada | `HERO_VIDEO` (archivos en `public/video/`) |
| Video de la intro | `public/video/intro-capitan.mp4` y `.webm` (original en `assets-src/`) |
| Aviso de privacidad | `T.privacy` |
| Sección de eventos y grupos | `T.events` |
| Dominio final (SEO, sitemap, imágenes para redes) | `SITE_URL` |

Los datos en `null` se muestran con el marcador **"Por confirmar"**. Cuando todo esté
confirmado, cambia `SHOW_PENDING_MARKERS` a `false`.

La carta (`MENU`) sale de la carta oficial en PDF (English Menu, 4 páginas).
Las reservas abren WhatsApp (`CONTACT.whatsapp`) con el mensaje ya escrito.

## Pendiente del restaurante

- Dominio final: ponerlo en `SITE_URL` y volver a compilar. Con eso se generan la URL canónica,
  `sitemap.xml` y las imágenes absolutas para WhatsApp/Facebook. Los datos para Google (horario,
  ubicación, carta con precios) se generan solos desde `site.ts` con `scripts/seo.ts`.

Para publicar la vista previa como Artifact (sin el iframe de Google Maps, que ahí no carga):
`VITE_ARTIFACT=1 npx vite build && python3 scripts/build-artifact.py`.
Para el sitio real usa `npm run build`, que sí incluye el mapa embebido.

## Reseñas

`src/content/resenas.json` (panel → Reseñas) contiene reseñas reales de Google Maps copiadas sin editar,
en su idioma original. Solo se agregan reseñas reales; la primera se muestra destacada.

## Estructura

```
src/
  data/site.ts          contenido central
  lib/                  idioma (ES/EN), curvas de animación, media queries
  components/           una sección por archivo (Intro, Hero + QuickBook, Favorites, Manifesto,
                        Sunset, Experience, Reviews, Visit, Footer, MenuOverlay,
                        BookingDrawer, MobileBar, Privacy, Cursor)
  styles/global.css     sistema visual: paleta, tipografía, secciones
assets-src/             fotos y logo originales
public/images/          imágenes optimizadas (generadas)
```
