import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { photos } from './scripts/photos'
import { seo } from './scripts/seo'

// base relativa: el sitio funciona desde cualquier carpeta o dominio
export default defineConfig({
  base: './',
  plugins: [react(), seo(), photos()],
  build: { target: 'es2020', cssCodeSplit: false },
})
